<?php 
$timestamp = strtotime($ans['movie_release_date']); 
$new_date = date('M d,Y', $timestamp); //  Date Format:- May 25,2018

$todate = date('Y-m-d\TH:i:s');



$year = date('Y', $timestamp); ?>

<script>
$(document).find('.slider-info').html('');

var metaKeyWord = "<?php echo $ans['movie_meta_title']; ?>";
$("meta[name='keywords']").attr('content', metaKeyWord);

var metaDescription = "<?php echo $ans['movie_meta_description']; ?>";
$("meta[name='description']").attr('content', metaDescription);

</script>

<div class="col-12">
	<h1 class="set-hed"><?php echo $ans['movie_name']; ?> || Free Download HD Movies <?php echo $year; ?></h1>
	<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-2"><?php echo $new_date; ?></span></time>
	<hr class="bg-dark"/>
</div>

<div class="col-12">
	<p><?php echo $ans['movie_description']; ?></p>
</div>

<div class="col-12 text-center py-2">
	<h6>Latest Movie <?php echo $ans['movie_full_name']; ?> Movie Torrent Link Available In Bottom</h6>
</div>

<div class="col-12 py-2 text-center">
	<h2><?php echo $ans['movie_full_name']; ?> Movie Poster <?php echo $year; ?></h2>
	<figure>
		<img src='images/movie-img/<?php echo $ans['movie_info_img']; ?>' class="img-fluid" alt="Pad Man Torrent 2018 Hindi Movie Poster" title="Pad Man Torrent 2018 Hindi Movie Poster"/>
	</figure>
</div>

<div class="col-12 d-flex">
	<div class="box"><strong>Full Movie Name:-</strong></div>
	<div class="box"><?php echo $ans['movie_full_name']; ?></div>	
</div>

<div class="col-12 d-flex">
	<div class="box"><strong>Movie Genres:-</strong></div>
	<div class="box"><?php echo $ans['movie_genres']; ?></div>	
</div>

<div class="col-12 d-flex">
	<div class="box"><strong>Movie Release Year:-</strong></div>
	<div class="box">2018</div>	
</div>

<div class="col-12 d-flex">
	<div class="box"><strong>Movie Language:-</strong></div>
	<div class="box"><?php echo $ans['movie_language']; ?></div>	
</div>

<div class="col-12 d-flex">
	<div class="box"><strong>Movie Size:-</strong></div>
	<div class="box"><?php echo $ans['movie_size']; ?></div>	
</div>

<div class="col-12 d-flex">
	<div class="box"><strong>Movie Quality:-</strong></div>
	<div class="box"><?php echo $ans['movie_quality']; ?></div>	
</div>

<div class="col-12 text-center text-light mt-3">
	<h3 class="bg-main py-2 mb-3">Storyline & Keyword</h3>
	<p class="px-3"><?php echo $ans['movie_story_line']; ?><br><a href="https://www.imdb.com/" target="_blank">IMDB</a></p>
</div>


<?php 
$cast_list = explode('###@@@', $ans['movie_cast']);

$cast_list_show = '';
if (isset($cast_list) && !empty($cast_list)) {
	$i = 1;
	$cast_list_show .= '
	<div class="col-12 text-light mt-3">
		<h3 class="bg-main py-2 mb-3 text-center">Movie Cast</h3>
		<div class="row no-gutters">';

	foreach($cast_list as $cast_info) {
		$single_cast = explode('***+++', $cast_info);

		$cast_list_show .= '
		<div class="col-12 border">
			<div class="row no-gutters borde">
				<div class="col-4 p-2">
					<h6>'.$i.'.</h6>
				</div>
				<div class="col-4 text-dark align-self-center title-txt">
					<a class="open-new-tab" href="https://www.google.co.in/search?q='.$single_cast[0].'" data-link-show="https://www.google.co.in/search?q='.$single_cast[0].'">'.$single_cast[0].'</a>
				</div>
				<div class="col-4 text-dark align-self-center">
					<p class="m-0">'.$single_cast[1].'</p>
				</div>
			</div>
		</div>';
		$i++;
	}
	$cast_list_show .= '
		</div>
	</div>';
}
echo $cast_list_show;
?>

<!-- <div class="col-12 my-4">
	<h3 class="bg-main text-center text-light py-2"><?php // echo $ans['movie_name']; ?> <?php // echo $year; ?> Poster</h3>
	<figure>
		<img src='images/movie-img/<?php // echo $ans['movie_info_img']; ?>' class="img-fluid" alt="Pad Man Torrent 2018 Hindi Movie Poster" title="Pad Man Torrent 2018 Hindi Movie Poster"/>
	</figure>
</div> -->


<div class="col-12">
	<h3 class="bg-main p-2 mb-3 mt-3 text-center text-light"> Movie Trailer</h3>
	<div class="embed-responsive embed-responsive-16by9">
		<iframe src="<?php echo $ans['movie_trailer_link']; ?>"></iframe>
	</div>
</div>



<div class="col-12">
	<h3 class="bg-main p-2 mb-3 mt-3 text-center text-light"><?php echo $ans['movie_full_name']; ?> || Full Movie Details</h3>
	<p class="py-2 text-center"><?php echo $ans['movie_story_details']; ?><br>
		<a href="#" target="_blank" class="open-new-tab" data-link-show="https://en.wikipedia.org/wiki/<?php echo $ans['movie_name']; ?>">Wikipedia</a></p>
</div>

<?php 
$data['id_movie_info'] = $ans['id_movie_info'];
$movie_image = $connection->selectMovieSliderImage($data);
$count_image = mysqli_num_rows($movie_image);
// echo $count_image;
$full_movie_slider_show = '';
if ($count_image > 0) {
	$full_movie_slider_show = '';
	$i = 1;
	$full_movie_slider_show .= '
	<div class="col-12">
		<h3 class="bg-main p-2 mb-0 text-center text-light">'.$ans['movie_full_name'].'Movie Result Sample Pictures</h3>
		
		<div class="movie-slider-info owl-carousel owl-theme my-3">';

	while($ans_movie_image = mysqli_fetch_assoc($movie_image)) {
		$full_movie_slider_show .= '<div class="item">
			<figure>
				<a class="open-new-tab" href="'.$ans_movie_image['movie_image_link'].'" data-link-show="'.$ans_movie_image['movie_image_link'].'">
					<img src="images/movie-slider-img/'.$ans_movie_image['movie_image_name'].'" class="img-fluid" alt="'.$i.'" title="'.$i.'"/>
				</a>
			</figure>
		</div>';
	}
	$full_movie_slider_show .= '
		</div>
	</div>';
}
echo $full_movie_slider_show;
?>

<div class="col-12 text-center">
	<h3 class="bg-main p-2 text-light"><?php echo $ans['movie_full_name']; ?> Movie Download Links</h3>
	
	<?php 
	$movie_entry_datetime = strtotime($ans['movie_entry_datetime']); 
	$movie_entry_datetime = date('d M Y', $movie_entry_datetime); //  Date Format:- 13 May 2018
	?>
	<h6 class="py-2 down"><b>Movie Download Link Update <?php echo $movie_entry_datetime; ?> </b></h6>


	<?php
		$id = $ans['id_movie_info'];
		$res = str_split($id);
		$count = count($res);
		$random = rand(11111,99999);
		$pass_data = $random.$id;
	?>

	<a href="#id" class="flipper-container open-new-tab" data-link-show="<?php echo 'link.php?id='.$pass_data; ?>">
		<div id="id" class="flipper">
			<div class="front-face" data-icon="&#x27a3;"><span data-hover="Clicked">Download</span></div>
			<div class="back-face" data-icon="&#10003;">Thank You</div>
		</div>
	</a>
	<?php
		$id = $ans['id_movie_info'];
		$res = str_split($id);
		$count = count($res);
		$random = rand(11111,99999);
		$pass_data = $random.$id;
	?>
	<a href="#id1" class="flipper-container open-new-tab" data-link-show="<?php echo 'link.php?id='.$pass_data; ?>">
		<div id="id1" class="flipper">
			<div class="front-face" data-icon="&#x27a3;"><span data-hover="Clicked">Download</span></div>
			<div class="back-face" data-icon="&#10003;">Thank You</div>
		</div>
	</a>
	<?php
		$id = $ans['id_movie_info'];
		$res = str_split($id);
		$count = count($res);
		$random = rand(11111,99999);
		$pass_data = $random.$id;
	?>
	<a href="#id2" class="flipper-container open-new-tab" data-link-show="<?php echo 'link.php?id='.$pass_data; ?>">
		<div id="id2" class="flipper">
			<div class="front-face" data-icon="&#x27a3;"><span data-hover="Clicked">Download</span></div>
			<div class="back-face" data-icon="&#10003;">Thank You</div>
		</div>
	</a>
</div>

<!-- <div class="col-12 text-center">
	<h6 class="pt-3 pb-5 down"><b><?php // echo $ans['movie_full_name']; ?> Full Movies Download Torrent File || Movie Magnet Torrent Download</b></h6>

	<?php // $download_file = BASE_URL.'upload-link-file/'.$ans['movie_link_file'];?>
 	<a href="<?php // echo $download_file; ?>" download='<?php // echo $ans['movie_link_file']; ?>'>
	 	<div class="button text-light mt-5 mb-5">
			<div class="don">
				<em>Download</em>
				<i class="fa fa-download"></i>
			</div>
		</div>
	</a>
</div> -->


<div class="col-12 text-center">
	<h6 class="pt-3 pb-5 down"><b><?php echo $ans['movie_full_name']; ?> Full Movies Download Torrent File || Movie Magnet Torrent Download</b></h6>

 	<a class="open-new-tab" href='#' data-link-show="<?php echo $ans['movie_final_link']; ?>" alt="<?php echo $ans['movie_full_name']; ?>">
	 	<div class="button text-light mt-5 mb-5">
			<div class="don">
				<em>Download</em>
				<i class="fa fa-download"></i>
			</div>
		</div>
	</a>
</div>



<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" crossorigin="anonymous"></script> -->
<!-- <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script> -->
<!-- <script src="Owl-JS/jquery.min.js"></script> -->
<!-- <script src="Owl-JS/owl.carousel.min.js"></script> -->
<script>

$(document).ready(function(){
	$('.movie-slider-info').owlCarousel({
	    loop:true,
		dots:false,
		autoplay:true,
		autoplayTimeout:2000,
	    margin:10,
	    responsiveClass:true,
	    responsive:{
	        0:{
	            items:1,
	        },
	        600:{
	            items:1,
	        },
	        1000:{
	            items:2,
	        }
	    }
	});
	$('.open-new-tab').click(function(e){
		e.preventDefault();
		console.log('right');
		var data = $(this).attr('data-link-show');
		window.open(data);
	});
});
</script>

