<?php

include_once('connection.php');
$html = '';
if (isset($_GET['data']) && !empty($_GET['data'])) {
	$html = '';
	if ($_GET['data'] == 'index') {
		$data = '';
	} else {
		$data = $_GET['data'];
	}

	
}


echo $html;