<?php 
include_once('connection.php');

if (isset($_POST['submits'])) {
    $data = array();
    $data['name'] = addslashes($_POST['name']);
    $data['email'] = addslashes($_POST['email']);
    $data['msg'] = addslashes($_POST['msg']);

    $result = $connection->insertCustomerContactInformation($data);
    if ($result) {
        header("Location:Contact-Form.php?ans=success");
    } else {
        header("Location:Contact-Form.php?ans=fail");
    }
    exit;
}


?>

<!doctype html>
<html lang="en">
<head>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-120213160-4"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-120213160-4');
</script>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width">
<meta name="robots" content="index|follow">
<meta name="description" content="freemovie4you.com is online free movies download website.this website provide a best quality movies. freemovie4you also provide a large collection of different movies like bollywood, hollywood, south and gujarati movies.You can free download any movies without login or registration.">
<meta name="keywords" content="freemovie4you, freemovies4you, free movies download, hd movies download, movie download site, bollywood movies download">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="googlebot" content="index, follow" />
<meta property="og:image" content="https://freemovie4you.com/movie-web/images/freemovie4you-poster.jpg" />
<meta property="og:description" content="Bollywood, Hollywood, South and Gujarati Full HD Free Movies Download Now" />
<meta property="og:url" content="https://www.freemovie4you.com" />
<title>Contact Form</title>
        <link href="images/popcorn.png" rel="icon">
	<link href="bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	<link href="css/style.css" rel="stylesheet" type="text/css"/>
	<link href="css/media-query.css" rel="stylesheet" type="text/css"/>
	<link href="css/fontawesome-all.min.css" rel="stylesheet" type="text/css"/>
</head>
<body>

	<?php include_once('header_show.php'); ?>
    <div class="container-fluid">
    	<div class="container">
        	<div class="row pt-2 pb-2 justify-content-center my-5">
            	<div class="col-lg-5 contact-box">
                	<form method="post" name="vform" action="Contact-Form.php" onsubmit="return check()">
                    	<div class="contact-value contact-header">
                        	<label>Contect US !</label>
                        </div>
                    	<div class="contact-value">
                        	<label>Name *</label>
                        </div>
                        <div class="contact-value">
                        	<input type="text" placeholder="Enter Your name" class="input-flex-box" name="name" id="names">
                        </div>
                     	<div class="contact-value">
                        	<label>Email *</label>
                        </div>
                        <div class="contact-value">
                        	<input type="email" placeholder="Youremail@address.com"  class="input-flex-box" name="email" id="emails">
                        </div>
                        <div class="contact-value">
                        	<label>Message *</label>
                        </div>
                        <div class="contact-value">
                        	<textarea class="input-flex-box-messge" name="msg" id="msgs"> </textarea>
                        </div>
                        <div class="contact-value">
                        	<label id="Error_msg">
                            <?php 
                            if (isset($_GET['ans'])) {
                                if ($_GET['ans'] == 'success')
                                    echo "Your Message is Successfully Send";
                                elseif ($_GET['ans'] == 'fail') 
                                    echo "Your Message is not Successfully Send. Please Try Again.";
                            }

                            ?>
                            </label>
                        </div>
                        <div class="contact-btn-flex">
                        	<input type="submit" value="Submit" class="contact-auto" name="submits" id="submits">
							<input type="reset" value="Reset" class="contact-auto">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php include_once("footer.php"); ?>

    
	
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" crossorigin="anonymous"></script>
	<script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
<script type="text/javascript">
	
	function check(){
		var x1 = document.getElementById("names").value;
		var x2 = document.getElementById("emails").value;
		var x3 = document.getElementById("msgs").value;
		var em = document.getElementById("Error_msg").value;
		var alphaExp = /^[a-zA-Z]+$/;
		if(x1=="" || x2=="" || x3=="")
		{
			document.getElementById("Error_msg").innerHTML = "All Filed Are Required";
			return false;
		}
		else{
			if(x1.match(alphaExp))
			{
					return ture;
			}
			else
			{
				document.getElementById("Error_msg").innerHTML = "Enter Valid Name";
					return false;
			}
			return ture;
		}
	}

    
$(document).on('click','.subscribe-input',function(){
    var emailaddress = $('.input-set-sub').val();
    if( validateEmail(emailaddress)) { 
        $.ajax({
        type: 'GET',
        url: 'insert-email.php?email-id='+emailaddress,
        cache: false,
        success: function(data)
        {
            if (data == 'confirm') {
                alert('Your Email is Subscribe.');
                $('.input-set-sub').val('');
            } else if(data =='email_already_register') {
                alert('Your Email is already Register.');
            } else {
                alert('Connection Error Accour.');
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
        }
    });
    } else {
        alert('Please Enter Valid Email Address.');
    }
});

function validateEmail($email) {
  var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
  return emailReg.test( $email );
}
</script>	
</body>
</html>
