<?php include_once('connection.php'); 

$data['page'] = (isset($_GET['page']) && !empty($_GET['page']) ? $_GET['page'] : 'index');

if (isset($_GET['search']) && !empty($_GET['pagin'])) {
	$data['search'] = $_GET['search'];
}

$data['start'] = (isset($_GET['pagin']) && !empty($_GET['pagin']) ? $_GET['pagin'] : '1');
$data['search'] = (isset($_GET['search']) && !empty($_GET['search']) ? $_GET['search'] : '');


$total_page_number = $connection->setPaginationInformation($data);
?>

<?php if($total_page_number != 0) { ?>
<div class="container-fluid d-flex">
	<div class="row mx-auto">

		<?php 
		$html = '';
		$current = (isset($_GET['pagin']) && !empty($_GET['pagin']) ? $_GET['pagin'] : 1);

           	if(3 <= $current && $current <= $total_page_number-2)
            {
                $start = $current-2;
                $end = $current+2;
            }
            elseif(2 == $current && $current <= $total_page_number-2)
            {
                $start = $current-1;
                $end = $current+2;
            }
            elseif(2 == $current && $current== $total_page_number)
            {
                $start = $current-1;
                $end = $current;
            }
            elseif(2 == $current && $current <= $total_page_number-1)
            {
                $start = $current-1;
                $end = $current+1;
            }
            elseif(1 == $current && $current <= $total_page_number-2)
            {
                $start = $current;
                $end = $current+2;
            }
            elseif(1 == $current && $current == $total_page_number-1)
            {
                $start = $current;
                $end = $current+1;
            }
            elseif(1 == $current && $current == $total_page_number)
            {
                $start = $current;
                $end = $current;
            }
            elseif(2 == $current && $current == $total_page_number)
            {
                $start = $current-1;
                $end = $current+1;
            }
            elseif(2 == $current && $current == $total_page_number-1)
            {
                $start = $current;
                $end = $current+1;
            }
            elseif(3<= $current && $total_page_number== $current+1)
            {
                $start = $current-2;
                $end = $current+1;
            }
            elseif(3<= $current && $total_page_number== $current)
            {
                $start = $current-2;
                $end = $current;
            }

        $pagination_url = BASE_URL.'?page='.$data['page'];

        if (!empty($data['search'])){
            $pagination_url .= '&search='.$data['search'];
        }

        $html .= '<a href=\''.$pagination_url.'&pagin=1'.'\' class=\'movie-pagin start\' data-pagin=\'1\'><span><i class="fas fa-angle-double-left"></i></span></a>';

        // if ($current >= 4) {
        // 	$html .= '<a href=\'#\' class=\'movie-pagin start\' data-pagin=\'1\'><span>1</span></a>';
        // }

		for($i=$start;$i<=$end;$i++) {
			$html .= '<a href=\''.$pagination_url.'&pagin='.$i.'\' class=\'movie-pagin '.($i == $current ? 'current' : '').'\' data-pagin=\''.$i.'\'><span>'.$i.'</span></a>';
		}

        // if ($current+3 <= $total_page_number) {
        // 	$html .= '<a href=\'#\' class=\'movie-pagin end\' data-pagin=\''.$total_page_number.'\'><span>'.$total_page_number.'</span></a>';
        // }

        // if ($current+3 <= $total_page_number) {
        $html .= '<a href=\''.$pagination_url.'&pagin='.$total_page_number.'\' class=\'movie-pagin end\' data-pagin=\''.$total_page_number.'\'><span><i class="fas fa-angle-double-right"></i></span></a>';
        // }

		echo $html; ?>
	</div>
</div>
<?php } ?>
