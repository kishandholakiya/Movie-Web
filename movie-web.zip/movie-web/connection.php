<?php

$display_errors = true;
ini_set('display_errors', $display_errors);

if (!$display_errors) {	
	ini_set('error_reporting', E_ERROR | E_WARNING | E_PARSE );
}


// remove this connect
// $actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]/movie-web/";


// remove this line
$actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://localhost/movie-web/";


define("BASE_URL", $actual_link);


class Connection
{
	static $con;
	public function __construct()
	{
		self::$con = mysqli_connect('localhost', 'root', '', 'movie-web');
	}

	public function selectMovieType($data)
	{
		$query = 'SELECT * FROM wb_movie_type  WHERE main_type_status = \'1\' ORDER BY main_type_position';
		$return_data = mysqli_query(self::$con, $query);
		return $return_data;
	}

	public function selectMovieList($data)
	{
		$data['limit'] = 21;
		$data['start'] = ($data['start'] != 0 ? (($data['start'] -1) * $data['limit']) : 0);
		$query = '';

		$todate = date('Y-m-d\TH:i:s');

		$query .= 'SELECT id_movie_info, movie_name, movie_sub_title, movie_description, movie_release_date, movie_entry_datetime, movie_link, id_movie_type, movie_is_status, movie_info_img FROM wb_movie_info WHERE movie_is_status = \'1\' AND movie_release_date<=\''.$todate.'\'';
		if (!empty($data['id_movie_type']) && $data['id_movie_type'] != 'index' && $data['id_movie_type'] !='5')
		{
			$query .= ' AND id_movie_type='.$data['id_movie_type'].'';
		}

		if (isset($data['search']) && !empty($data['search']))
		{
			$query .= ' AND movie_name LIKE \'%'.$data['search'].'%\'';
		}

		$query .= ' ORDER BY movie_entry_datetime DESC,movie_position';
		$query .= ' LIMIT '.$data['start'].','.$data['limit'];

		$return_data = mysqli_query(self::$con, $query);
	
		return $return_data;
	}

	public function setPaginationInformation($data)
	{
		// same as limit   /******* $data['limit'] = 21; ***********/ as above function
		$show_total_list = 21;
		$query = '';

		$todate = date('Y-m-d\TH:i:s');
		
		$query = 'SELECT COUNT(id_movie_info) as count FROM wb_movie_info  WHERE movie_is_status = \'1\' AND movie_release_date<=\''.$todate.'\'';
		

		$check_search_page = false;
		if (isset($data['search']) && !empty($data['search']))
		{
			$query .= ' AND movie_name LIKE \'%'.$data['search'].'%\'';
			$check_search_page = true;
		}

		if (!empty($data['page']) && $data['page'] != 'index' && $data['page'] != '5' && !$check_search_page) {
			$query .= ' AND id_movie_type='.$data['page'].'';
		}

		$return_data = mysqli_query(self::$con, $query);
		$ans = mysqli_fetch_array($return_data);
		$count = $ans['count'];

		$pagination_number = ceil($count/$show_total_list);
		return $pagination_number;
	}

	public function selectSliderInformation($data)
	{
		$query = 'SELECT * FROM wb_slider WHERE slider_is_status = \'1\' ORDER BY slider_entry_datetime DESC ';
		$return_data = mysqli_query(self::$con, $query);
		return $return_data;
	}

	public function selectSliderInformation2($data)
	{
		$query = 'SELECT * FROM wb_slider2 WHERE slider_is_status = \'1\' ORDER BY slider_entry_datetime DESC ';
		$return_data = mysqli_query(self::$con, $query);
		return $return_data;
	}

	public function selectUpcommingMovie($data)
	{
		$todate = date('Y-m-d\TH:i:s');

		$query = 'SELECT * FROM wb_movie_info  WHERE movie_is_status = \'1\' AND movie_release_date>=\''.$todate.'\' ORDER BY movie_release_date ASC LIMIT '.$data['start'].','.$data['limit'];
		$return_data = mysqli_query(self::$con, $query);
		return $return_data;
	}

	public function selectFullMovieList($data)
	{
		$query = 'SELECT * FROM wb_movie_info WHERE id_movie_info='.$data['movie'];
		$return_data = mysqli_query(self::$con, $query);
		return $return_data;
	}

	public function selectMovieCast($data)
	{
		$query = 'SELECT * FROM wb_movie_cast WHERE id_movie_info='.$data['id_movie_info'];
		$return_data = mysqli_query(self::$con, $query);
		return $return_data;
	}

	public function selectMovieSliderImage($data)
	{
		$query = 'SELECT * FROM wb_movie_image WHERE id_movie_info='.$data['id_movie_info'];
		$return_data = mysqli_query(self::$con, $query);
		return $return_data;
	}

	public function selectMovieLink($data)
	{
		$query = 'SELECT * FROM wb_movie_info WHERE id_movie_info='.$data['id_movie_info'];
		$return_data = mysqli_query(self::$con, $query);
		return $return_data; 
	}

	public function checkEmailIdForSubscribe($email)
	{
		$query = 'SELECT * FROM wb_movie_email_list WHERE wb_movie_email_list_email_id=\''.$email.'\'';
		$return_data = mysqli_query(self::$con, $query);
		$ans = mysqli_fetch_assoc($return_data);
		// echo "<pre>";
		if (empty($ans)) {
			return true;
		} else {
			return false;
		}
	}

	public function insertEmailSubscribe($email)
	{
		$entry_date = date('Y-m-d\TH:i:s');

		$query = 'INSERT INTO wb_movie_email_list 
			SET 
				wb_movie_email_list_id = NULL,
				wb_movie_email_list_email_id = \''.$email.'\',
				wb_movie_email_list_entry_time = \''.$entry_date.'\',
				wb_movie_email_list_status = \'1\'';
		$return_data = mysqli_query(self::$con, $query);
		return $return_data;
	}

	public function insertCustomerContactInformation($data)
	{
		$date = date("Y/m/d h:i:sa");
		$query = 'INSERT INTO wb_movie_customer_info
			SET 
				wb_movie_customer_id = NULL,
				wb_movie_customer_name = \''.$data['name'].'\',
				wb_movie_customer_email_id = \''.$data['email'].'\',
				wb_movie_customer_message = \''.$data['msg'].'\',
				wb_movie_customer_entry_date_time = \''.$date.'\',
				wb_movie_customer_is_status = \'1\'';
		$return_data = mysqli_query(self::$con, $query);
		return $return_data;
	}
}

$connection = new Connection();
