<?php include_once('connection.php'); ?>
<!doctype html>
<html>
<head>

<!-- PopAds.net Popunder Code for freemovie4you.com | 2018-08-19,2816067,0,0 -->
<script type="text/javascript" data-cfasync="false">
/*<![CDATA[/* */
/* Privet darkv. Each domain is 2h fox dead */
 (function(){ var m=window;m["\x5f\u0070\x6f\u0070"]=[["\x73i\x74\x65Id",2816067],["\x6d\x69\x6e\u0042\u0069\u0064",0],["\u0070\x6fp\u0075nd\u0065r\x73\u0050e\u0072\u0049\u0050",0],["\u0064\u0065\x6c\u0061\x79\x42\u0065\u0074\x77ee\x6e",0],["\x64efa\x75\x6c\u0074",false],["\x64\u0065\u0066\u0061\u0075\u006c\x74\x50\x65rD\x61y",0],["\u0074\x6fpm\u006f\u0073tL\u0061yer",!0]];var x=["\x2f\u002f\x63\u0031\u002e\x70o\u0070\u0061ds\x2e\x6ee\u0074/\x70\x6f\x70\u002e\u006a\x73","\x2f\x2f\x63\u0032.\x70\x6f\x70\u0061\x64\x73.\u006e\x65\u0074\x2fpo\u0070\u002ejs","\x2f/w\x77w\u002e\u0070tr\u0061\x68ww\u0067\x2e\x63o\u006d\x2f\x64q\x2ej\u0073","\x2f\u002f\x77\x77\u0077\x2ewcy\u0071\x6f\x69\u0079\u006f\u0068\u0068\x61v\x2ec\x6f\x6d/\u0066ip\u002e\x6a\u0073",""],s=0,t,i=function(){if(""==x[s])return;t=m["doc\u0075m\u0065\x6e\x74"]["crea\x74e\x45l\u0065m\u0065n\x74"]("\x73c\u0072\x69p\u0074");t["\u0074y\u0070\u0065"]="te\x78\x74\u002f\x6a\x61v\x61s\x63\x72\u0069\u0070t";t["a\x73\u0079\u006e\x63"]=!0;var y=m["\x64\x6f\x63u\x6den\x74"]["\u0067et\u0045\u006c\x65\u006d\u0065n\x74\x73\x42\u0079T\u0061\u0067\u004e\x61\x6d\u0065"]("\u0073\u0063\x72i\u0070\u0074")[0];t["sr\u0063"]=x[s];if(s<2){t["\u0063\u0072os\u0073O\x72\x69gi\x6e"]="\u0061\u006e\u006f\x6ey\u006d\x6f\u0075\u0073";};t["\u006f\x6ee\x72\x72\u006fr"]=function(){s++;i()};y["\u0070a\x72e\u006e\u0074\x4e\x6fd\x65"]["\x69\u006e\x73\x65\u0072t\u0042efo\x72\x65"](t,y)};i()})();
/*]]>/* */
</script>


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-120213160-4"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-120213160-4');
</script>

<script src="//platform.linkedin.com/in.js" type="text/javascript"> lang: en_US</script>
<script async src="js/page.js"></script>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width">
<meta name="robots" content="index|follow">
<meta name="keywords" content="freemovie4you, freemovies4you, free movies download, hd movies download, movie download site, bollywood movies download">
<meta name="description" content="freemovie4you is online free movies download website.this website provide a best quality movies. freemovie4you also provide a large collection of different movies like bollywood, hollywood, south and gujarati movies.You can free download any movies without login or registration.">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="googlebot" content="index, follow" />
<meta property="og:image" content="https://freemovie4you.com/movie-web/images/freemovie4you-poster.jpg" />
<meta property="og:description" content="Bollywood, Hollywood, South and Gujarati Full HD Free Movies Download Now" />
<meta property="og:url" content="https://www.freemovie4you.com" />
<title>
    Free Latest Movies Download Now - HD Quality Movies Avaliable
</title>
<link href="images/popcorn.png" rel="icon">
<link href="bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
<link href="css/media-query.css" rel="stylesheet" type="text/css"/>
<link href="css/fontawesome-all.min.css" rel="stylesheet" type="text/css"/>
<link href="Owl-CSS/owl.carousel.css" rel="stylesheet" type="text/css"/>
<link href="Owl-CSS/owl.carousel.min.css" rel="stylesheet" type="text/css"/>
<script src="js/jquery.min.js" type="text/javascript"></script>

</head>

<body>

<?php include_once("header.php"); ?>

<div class='container-fluid slider-info'>
    <?php include_once("slider.php"); ?>
</div>

<div class="container-fluid page-content py-4">

		<div class="row">
            <div class="col-sm-12 col-lg-8 title-txt my-1">
                <div class="row" id='movie-list-left-panel'>
        			<?php include_once("left-panel.php"); ?>
                </div>
            </div>
		
        	<?php include_once("right-panel.php"); ?>
		</div>

</div>

<div id="movie-list-pagination">
    <?php include_once("pagination.php"); ?>
</div>
<?php include_once("footer.php"); ?>

<script src="js/jquery-3.2.1.slim.min.js" crossorigin="anonymous"></script>
<script src="js/popper.min.js" crossorigin="anonymous"></script>



<script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>

<script src="Owl-JS/jquery.min.js"></script>
<script src="Owl-JS/owl.carousel.min.js"></script>
<script>

showConsoleWrarring();
function showConsoleWrarring()
{
    var textonly = false;

    var start = function() {
        var i = "Stop!",
            j = "This is a browser feature intended for developers. If someone told you to copy-paste something here to enable a www.freemovie4you.com feature or \"hack\" someone's account, it is a scam and will give them access to your www.freemovie4you.com account.",
            k = "See https://www.freemovie4you.com/selfxss for more information.";
        if ((window.chrome || window.safari) && !textonly) {
            var l = 'font-family:helvetica; font-size:20px; ';
            [
                [i, l + 'font-size:50px; font-weight:bold; color:red; -webkit-text-stroke:1px black;'],
                [j, l + ''],
                [k, l + ''],
                ['', '']
            ].map(function(r) {
                setTimeout(console.log.bind(console, '\n%c' + r[0], r[1]));
            });
        } else {
            var m = ['', ' .d8888b.  888                       888', 'd88P  Y88b 888                       888', 'Y88b.      888                       888', ' "Y888b.   888888  .d88b.  88888b.   888', '    "Y88b. 888    d88""88b 888 "88b  888', '      "888 888    888  888 888  888  Y8P', 'Y88b  d88P Y88b.  Y88..88P 888 d88P', ' "Y8888P"   "Y888  "Y88P"  88888P"   888', '                           888', '                           888', '                           888'],
                n = ('' + j).match(/.{35}.+?\s+|.+$/g),
                o = Math.floor(Math.max(0, (m.length - n.length) / 2));
            for (var p = 0; p < m.length || p < n.length; p++) {
                var q = m[p];
                m[p] = q + new Array(45 - q.length).join(' ') + (n[p - o] || '');
            }
            console.log('\n\n\n' + m.join('\n') + '\n\n' + k + '\n');
            return;
        }
    }();
}

sliderJs();
function sliderJs() {
	$('.main-slider-info').owlCarousel({
        loop:true,
    	dots:false,
    	autoplay:true,
    	autoplayTimeout:2000,
        margin:10,
        responsiveClass:true,
        responsive:{
            0:{
                items:1,
            },
            600:{
                items:3,
            },
            1000:{
                items:6,
            }
        }
    });
}

$(document).on('click','.subscribe-input',function(){
    var emailaddress = $('.input-set-sub').val();
    if( validateEmail(emailaddress)) { 
        $.ajax({
        type: 'GET',
        url: 'insert-email.php?email-id='+emailaddress,
        cache: false,
        success: function(data)
        {
            if (data == 'confirm') {
                alert('Your Email is Subscribe.');
                $('.input-set-sub').val('');
            } else if(data =='email_already_register') {
                alert('Your Email is already Register.');
            } else {
                alert('Connection Error Accour.');
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
        }
    });
    } else {
        alert('Please Enter Valid Email Address.');
    }
});

function validateEmail($email) {
  var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
  return emailReg.test( $email );
}

$(document).ready(function(){
    $('.main-slider-info-2').owlCarousel({
        loop:true,
        dots:false,
        autoplay:true,
        autoplayTimeout:2000,
        margin:10,
        responsiveClass:true,
        responsive:{
            0:{
                items:1,
            },
            600:{
                items:1,
            },
            1000:{
                items:1,
            }
        }
    });
});


</script>

</body>
</html>
