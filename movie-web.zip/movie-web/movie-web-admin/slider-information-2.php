<?php include_once('connection.php'); 
 
$check_login = $connection->checkCookie();
if (!$check_login) {
    header("Location:index.php");
}

if (isset($_GET['delete-slider-id']) && !empty($_GET['delete-slider-id'])) {
    $del_id = $_GET['delete-slider-id'];
    $res = $connection->deleteSlider2($del_id);
    if ($res) {
        header("Location:slider-information-2.php?del-id=confirm");
    } else {
        header("Location:slider-information-2.php?del-id=not-confirm");
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <title>Ela - Bootstrap Admin Dashboard Template</title>
    <!-- Bootstrap Core CSS -->
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:** -->
    <!--[if lt IE 9]>
    <script src="https:**oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https:**oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body class="fix-header fix-sidebar">
    <!-- Preloader - style you can find in spinners.css -->
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>
    <!-- Main wrapper  -->
    <div id="main-wrapper">
        <?php include_once("header.php"); ?>
        <!-- End header header -->
        <!-- Left Sidebar  -->
        <?php include_once("left_panel.php"); ?>
        <!-- End Left Sidebar  -->
        <!-- Page wrapper  -->
        <div class="page-wrapper">
            <div class="container-fluid">
                <!-- Start Page Content -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Slider List </h4>
                                <h6 class="card-subtitle">Show all Slider Information</h6>

                                <h5> For Add New Slider Information <a href="add-edit-slider-info-2.php"><button>Click Here</button></a></h5>

                                <?php
                                $html = '';
                                if (isset($_GET['del-id']) && !empty($_GET['del-id']))
                                {
                                    if ($_GET['del-id'] == 'confirm') {
                                        $html .= 'Slider is Deleted';
                                    }elseif ($_GET['del-id'] == 'not-confirm') {
                                        $html .= 'Slider is Not Deleted';
                                    }
                                }
                                echo '<p>'.$html.'</p>';
                                ?>

                                <div class="table-responsive m-t-40">
                                    <table id="example" class="table display table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>Status</th>
                                                <th>Image</th>
                                                <th>Title</th>
                                                <th>Link</th>
                                                <th>Entry Date</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>

                                        <tbody>

                                        <?php 
                                        $data = array();
                                        // echo $_GET['page'];
                                        $data['start'] = (isset($_GET['page']) && !empty($_GET['page']) ? $_GET['page'] : 1);

                                        $return = $connection->selectSliderList2($data); 
                                        $html = '';
                                        while ($ans = mysqli_fetch_assoc($return)) {
                                            $status = ($ans['slider_is_status'] == '1' ? 'green.png' : 'red.png');

                                            $img = $ans['slider_img'];
                                            $id = $ans['id_slider'];
                                            $name = $ans['slider_name'];
                                            $slider_link = $ans['slider_link'];


                                            $timestamp = strtotime($ans['slider_entry_datetime']); 
                                            $new_date = date('M d,Y', $timestamp);
                                            $entry_date= $new_date;


                                            $html .= '
                                            <tr>
                                                <td><img src=\'images/'.$status.'\' ></td>
                                                <td><img src=\''.BASE_CLIENT_URL.'images/slider-img2/'.$img.'\' width=\'30%\'></td>
                                                <td>'.$name.'</td>
                                                <td>'.$slider_link.'</td>
                                                <td>'.$entry_date.'</td>
                                                <td><a href=\'add-edit-slider-info-2.php?id='.$id.'\'>Edit</a><a href=\'slider-information-2.php?delete-slider-id='.$id.'\' onClick=\'return checkDelSlider();\'>Delete</a></td>
                                            </tr>
                                            ';
                                        }

                                        echo $html;
                                        ?>
                                        </tbody>
                                    </table>
                                </div>


                                <div id="slider-list-pagination">
                                    <div>
                                        <?php
                                        
                                        $data['start'] = (isset($_GET['page']) && !empty($_GET['page']) ? $_GET['page'] : 1);

                                        $total_page_number = $connection->setPaginationSliderInformation2($data); 
                                        $i = 1;
                                        $html = '';

                                        $current = (isset($_GET['page']) && !empty($_GET['page']) ? $_GET['page'] : 1);


                                        if(3 <= $current && $current <= $total_page_number-2)
                                        {
                                            $start = $current-2;
                                            $end = $current+2;
                                        }
                                        elseif(2 == $current && $current <= $total_page_number-2)
                                        {
                                            $start = $current-1;
                                            $end = $current+2;
                                        }
                                        elseif(2 == $current && $current== $total_page_number)
                                        {
                                            $start = $current-1;
                                            $end = $current;
                                        }
                                        elseif(2 == $current && $current <= $total_page_number-1)
                                        {
                                            $start = $current-1;
                                            $end = $current+1;
                                        }
                                        elseif(1 == $current && $current <= $total_page_number-2)
                                        {
                                            $start = $current;
                                            $end = $current+2;
                                        }
                                        elseif(1 == $current && $current == $total_page_number-1)
                                        {
                                            $start = $current;
                                            $end = $current+1;
                                        }
                                        elseif(1 == $current && $current == $total_page_number)
                                        {
                                            $start = $current;
                                            $end = $current;
                                        }
                                        elseif(2 == $current && $current == $total_page_number)
                                        {
                                            $start = $current-1;
                                            $end = $current+1;
                                        }
                                        elseif(2 == $current && $current == $total_page_number-1)
                                        {
                                            $start = $current;
                                            $end = $current+1;
                                        }
                                        elseif(3<= $current && $total_page_number== $current+1)
                                        {
                                            $start = $current-2;
                                            $end = $current+1;
                                        }
                                        elseif(3<= $current && $total_page_number== $current)
                                        {
                                            $start = $current-2;
                                            $end = $current;
                                        }

                                        $html .= '<a href=\'slider-information-2.php?page=1\' class=\'slider-pagin start movie-pagin\'><span>&lt;</span></a>';


                                        // if ($current >= 4) {
                                        //     $html .= '<a href=\'slider-information-2.php?page=1\' class=\'slider-pagin start\'><span>1</span></a>';
                                        // }

                                        for($i=$start;$i<=$end;$i++) {
                                            $html .= '<a href=\'slider-information-2.php?page='.$i.'\' class=\'slider-pagin\'><span>'.$i.'</span></a>';
                                        }

                                        // if ($current+3 <= $total_page_number) {
                                        //     $html .= '<a href=\'slider-information-2.php?page='.$total_page_number.'\' class=\'slider-pagin end\'><span>'.$total_page_number.'</span></a>';
                                        // }

                                        // if ($current+3 <= $total_page_number) {
                                            $html .= '<a href=\'slider-information-2.php?page='.$total_page_number.'\' class=\'slider-pagin end\'><span>&gt;</span></a>';
                                        // }
                                        echo $html;
                                        ?>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- End PAge Content -->
            </div>
            
        </div>
        <!-- End Page wrapper  -->
    </div>
    <!-- End Wrapper -->
    <!-- All Jquery -->
    <script src="js/lib/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Menu sidebar -->
    <script src="js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <!--Custom JavaScript -->
    <script src="js/scripts.js"></script>

<script>
function checkDelSlider()
{
    var del_confirm = confirm('Are you want to sure Delete Slider?');
    if (del_confirm == true) {
        return true;
    } else {
        return false;
    }
}
</script>

</body>

</html>