$(document).ready(function(){
    $(document).on('submit','.movie-data-form',function(){
        // var x = true;
        $('p.err-msg').remove();    
        var x = false;
        var tmpVal;
        
        tmpVal = $('input[name=movie_name]');
        if (jQuery.trim(tmpVal.val()) == null || jQuery.trim(tmpVal.val()) == '') {
            tmpVal.parent().append('<p class=\'err-msg\'>Please Enter Movie Name.</p>');
            x = false;
        } else {
            $('p.err-msg').remove();
            x = true;
        }

        tmpVal = $('input[name=movie_release_date]');
        if (jQuery.trim(tmpVal.val()) == null || jQuery.trim(tmpVal.val()) == '') {
            tmpVal.parent().append('<p class=\'err-msg\'>Please Enter Date and Time.</p>');
            x = false;
        } else {
            $('p.err-msg').remove();
            x = true;
        }

        tmpVal = $('input[name=movie_description]');
        if (jQuery.trim(tmpVal.val()) == null || jQuery.trim(tmpVal.val()) == '') {
            tmpVal.parent().append('<p class=\'err-msg\'>Please Enter Movie Content 1.</p>');
            x = false;
        } else {
            $('p.err-msg').remove();
            x = true;
        }

        tmpVal = $('input[name=movie_meta_title]');
        if (jQuery.trim(tmpVal.val()) == null || jQuery.trim(tmpVal.val()) == '') {
            tmpVal.parent().append('<p class=\'err-msg\'>Please Enter Meta Title.</p>');
            x = false;
        } else {
            $('p.err-msg').remove();
            x = true;
        }

        tmpVal = $('input[name=movie_meta_description]');
        if (jQuery.trim(tmpVal.val()) == null || jQuery.trim(tmpVal.val()) == '') {
            tmpVal.parent().append('<p class=\'err-msg\'>Please Enter Meta Description.</p>');
            x = false;
        } else {
            $('p.err-msg').remove();
            x = true;
        }

        tmpVal = $('input[name=movie_sub_title]');
        if (jQuery.trim(tmpVal.val()) == null || jQuery.trim(tmpVal.val()) == '') {
            tmpVal.parent().append('<p class=\'err-msg\'>Please Enter Movie Sub-Title.</p>');
            x = false;
        } else {
            $('p.err-msg').remove();
            x = true;
        }

        tmpVal = $('input[name=movie_sub_title_2]');
        if (jQuery.trim(tmpVal.val()) == null || jQuery.trim(tmpVal.val()) == '') {
            tmpVal.parent().append('<p class=\'err-msg\'>Please Enter Movie Sub-Title 2.</p>');
            x = false;
        } else {
            $('p.err-msg').remove();
            x = true;
        }

        tmpVal = $('input[name=movie_full_name]');
        if (jQuery.trim(tmpVal.val()) == null || jQuery.trim(tmpVal.val()) == '') {
            tmpVal.parent().append('<p class=\'err-msg\'>Please Enter Full Movie Name.</p>');
            x = false;
        } else {
            $('p.err-msg').remove();
            x = true;
        }

        tmpVal = $('input[name=movie_genres]');
        if (jQuery.trim(tmpVal.val()) == null || jQuery.trim(tmpVal.val()) == '') {
            tmpVal.parent().append('<p class=\'err-msg\'>Please Enter Movie Genres.</p>');
            x = false;
        } else {
            $('p.err-msg').remove();
            x = true;
        }

        tmpVal = $('input[name=movie_language]');
        if (jQuery.trim(tmpVal.val()) == null || jQuery.trim(tmpVal.val()) == '') {
            tmpVal.parent().append('<p class=\'err-msg\'>Please Enter Movie Language.</p>');
            x = false;
        } else {
            $('p.err-msg').remove();
            x = true;
        }

        tmpVal = $('input[name=movie_size]');
        if (jQuery.trim(tmpVal.val()) == null || jQuery.trim(tmpVal.val()) == '') {
            tmpVal.parent().append('<p class=\'err-msg\'>Please Enter Movie Size.</p>');
            x = false;
        } else {
            $('p.err-msg').remove();
            x = true;
        }

        tmpVal = $('input[name=movie_quality]');
        if (jQuery.trim(tmpVal.val()) == null || jQuery.trim(tmpVal.val()) == '') {
            tmpVal.parent().append('<p class=\'err-msg\'>Please Enter Movie Quality.</p>');
            x = false;
        } else {
            $('p.err-msg').remove();
            x = true;
        }

        tmpVal = $('input[name=movie_story_line]');
        if (jQuery.trim(tmpVal.val()) == null || jQuery.trim(tmpVal.val()) == '') {
            tmpVal.parent().append('<p class=\'err-msg\'>Please Enter Movie Story Line.</p>');
            x = false;
        } else {
            $('p.err-msg').remove();
            x = true;
        }

        tmpVal = $('input[name=movie_story_details]');
        if (jQuery.trim(tmpVal.val()) == null || jQuery.trim(tmpVal.val()) == '') {
            tmpVal.parent().append('<p class=\'err-msg\'>Please Enter Movie Story Details.</p>');
            x = false;
        } else {
            $('p.err-msg').remove();
            x = true;
        }

        tmpVal = $('input[name=movie_trailer_link]');
        if (jQuery.trim(tmpVal.val()) == null || jQuery.trim(tmpVal.val()) == '') {
            tmpVal.parent().append('<p class=\'err-msg\'>Please Enter Movie Trailer Link.</p>');
            x = false;
        } else {
            $('p.err-msg').remove();
            x = true;
        }

        tmpVal = $('input[name=movie_final_link]');
        if (jQuery.trim(tmpVal.val()) == null || jQuery.trim(tmpVal.val()) == '') {
            tmpVal.parent().append('<p class=\'err-msg\'>Please Enter Movie Final Link.</p>');
            x = false;
        } else {
            $('p.err-msg').remove();
            x = true;
        }


        tmpVal = $('.movie-cast-information input');
        if (jQuery.trim(tmpVal.val()) == null || jQuery.trim(tmpVal.val()) == '') {
            tmpVal.parent().parent().append('<p class=\'err-msg\'>Please Enter Movie Cast.</p>');
            x = false;
        } else {
            $('p.err-msg').remove();
            x = true;
        }

        tmpVal = $('.movie-link-info input');
        if (jQuery.trim(tmpVal.val()) == null || jQuery.trim(tmpVal.val()) == '') {
            tmpVal.parent().append('<p class=\'err-msg\'>Please Enter Movie Links.</p>');
            x = false;
        } else {
            $('p.err-msg').remove();
            x = true;
        }

        if(x===false) {
            return false;
        }
    });
});