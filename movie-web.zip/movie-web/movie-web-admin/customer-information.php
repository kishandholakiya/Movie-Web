<?php include_once('connection.php'); 

$check_login = $connection->checkCookie();
if (!$check_login) {
    header("Location:index.php");
}

if (isset($_GET['delete-movie-id']) && !empty($_GET['delete-movie-id'])) {
	$del_id = $_GET['delete-movie-id'];
	$res = $connection->deleteMovie($del_id);
	if ($res) {
		header("Location:movie-list.php?del-id=confirm");
	} else {
		header("Location:movie-list.php?del-id=not-confirm");
	}
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <title>Ela - Bootstrap Admin Dashboard Template</title>
    <!-- Bootstrap Core CSS -->
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:** -->
    <!--[if lt IE 9]>
    <script src="https:**oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https:**oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body class="fix-header fix-sidebar">
    <!-- Preloader - style you can find in spinners.css -->
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
			<circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>
    <!-- Main wrapper  -->
    <div id="main-wrapper">
        <?php include_once("header.php"); ?>
        <!-- End header header -->
        <!-- Left Sidebar  -->
        <?php include_once("left_panel.php"); ?>
        <!-- End Left Sidebar  -->
        <!-- Page wrapper  -->
        <div class="page-wrapper">
            <div class="container-fluid">
                <!-- Start Page Content -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Customer Information </h4>
                                <h6 class="card-subtitle">Show all Customer Information.</h6>

                                <?php
                                $html = '';
                                if (isset($_GET['del-id']) && !empty($_GET['del-id']))
                                {
                                	if ($_GET['del-id'] == 'confirm') {
                                		$html .= 'Movie is Deleted';
                                	}elseif ($_GET['del-id'] == 'not-confirm') {
                                		$html .= 'Movie is Not Deleted';
                                	}
                                }
                                echo '<p>'.$html.'</p>';
                                ?>

                                <div class="table-responsive m-t-40">
                                    <table id="example" class="table display table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Email Id</th>
                                                <th>Message</th>
                                                <th>Entry Date</th>
                                            </tr>
                                        </thead>

                                        <tbody>

                                        <?php 
                                        $data = array();
                                        $data['start'] = (isset($_GET['page']) && !empty($_GET['page']) ? $_GET['page'] : 1);

                                        $return = $connection->selectCustomerMessage($data); 

                                        $html = '';
                                        while ($ans = mysqli_fetch_assoc($return)) {
                                            $name = $ans['wb_movie_customer_name'];
                                            $email = $ans['wb_movie_customer_email_id'];
                                            $message = $ans['wb_movie_customer_message'];
                                            $timestamp = strtotime($ans['wb_movie_customer_entry_date_time']); 
                                            $entry_date = date('Y-m-d H:i a', $timestamp);

                                        	$html .= '
                                        	<tr>
                                                <td>'.$name.'</td>
                                                <td>'.$email.'</td>
                                                <td>'.$message.'</td>
                                                <td>'.$entry_date.'</td>
                                            </tr>
                                            ';
                                        }

                                        echo $html;
                                        ?>
                                        </tbody>
                                    </table>
                                </div>


                                <div id="movie-list-pagination">
                                    <div>
                                        <?php
                                        
                                        $data['start'] = (isset($_GET['page']) && !empty($_GET['page']) ? $_GET['page'] : 1);

                                        $total_page_number = $connection->setPaginationCustomerInformation($data); 
                                        $i = 1;
                                        $html = '';


                                        $current = (isset($_GET['page']) && !empty($_GET['page']) ? $_GET['page'] : 1);

                                        if(3 <= $current && $current <= $total_page_number-2)
                                        {
                                            $start = $current-2;
                                            $end = $current+2;
                                        }
                                        elseif(2 == $current && $current <= $total_page_number-2)
                                        {
                                            $start = $current-1;
                                            $end = $current+2;
                                        }
                                        elseif(2 == $current && $current== $total_page_number)
                                        {
                                            $start = $current-1;
                                            $end = $current;
                                        }
                                        elseif(2 == $current && $current <= $total_page_number-1)
                                        {
                                            $start = $current-1;
                                            $end = $current+1;
                                        }
                                        elseif(1 == $current && $current <= $total_page_number-2)
                                        {
                                            $start = $current;
                                            $end = $current+2;
                                        }
                                        elseif(1 == $current && $current == $total_page_number-1)
                                        {
                                            $start = $current;
                                            $end = $current+1;
                                        }
                                        elseif(1 == $current && $current == $total_page_number)
                                        {
                                            $start = $current;
                                            $end = $current;
                                        }
                                        elseif(2 == $current && $current == $total_page_number)
                                        {
                                            $start = $current-1;
                                            $end = $current+1;
                                        }
                                        elseif(2 == $current && $current == $total_page_number-1)
                                        {
                                            $start = $current;
                                            $end = $current+1;
                                        }
                                        elseif(3<= $current && $total_page_number== $current+1)
                                        {
                                            $start = $current-2;
                                            $end = $current+1;
                                        }
                                        elseif(3<= $current && $total_page_number== $current)
                                        {
                                            $start = $current-2;
                                            $end = $current;
                                        }

                                        if ($current >= 4) {
                                            $html .= '<a href=\'customer-information.php?page=1\' class=\'movie-pagin start\'><span>1</span></a>';
                                        }

                                        for($i=$start;$i<=$end;$i++) {
                                            $html .= '<a href=\'customer-information.php?page='.$i.'\' class=\'movie-pagin\'><span>'.$i.'</span></a>';
                                        }

                                        if ($current+3 <= $total_page_number) {
                                            $html .= '<a href=\'customer-information.php?page='.$total_page_number.'\' class=\'movie-pagin end\'><span>'.$total_page_number.'</span></a>';
                                        }
                                        echo $html;
                                        ?>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- End PAge Content -->
            </div>
            
        </div>
        <!-- End Page wrapper  -->
    </div>
    <!-- End Wrapper -->
    <!-- All Jquery -->
    <script src="js/lib/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Menu sidebar -->
    <script src="js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <!--Custom JavaScript -->
    <script src="js/scripts.js"></script>

<script>
	// $(document).ready(function(){
	// 	$('.movie-list-del-movie').click(function(e){
	// 		e.preventDefault();
	// 		var check_movie_delete = confirm('Are you want to sure Delete Movie?');
	// 		if (check_movie_delete == true) {
	// 			return true;
	// 		} else {
	// 			return false;
	// 		}
	// 	});
	// });

function checkDelMovie()
{
	var del_movie_confirm = confirm('Are you want to sure Delete Movie?');
	if (del_movie_confirm == true) {
		return true;
	} else {
		return false;
	}
}
</script>

</body>

</html>