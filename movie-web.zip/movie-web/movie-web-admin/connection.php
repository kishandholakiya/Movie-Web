<?php

session_start();

$display_errors = true;
ini_set('display_errors', $display_errors);

if (!$display_errors) {	
	ini_set('error_reporting', E_ERROR | E_WARNING | E_PARSE );
}

// remove this comment
// $actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]/movie-web-admin/";

// remove this one line
$actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]/movie-web/movie-web-admin/";
define("BASE_URL", $actual_link);

// remove this comment
// $actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]/";


// remove this one line.
$actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]/movie-web/";
define("BASE_CLIENT_URL", $actual_link);


class Connection
{
	static $con;
	public function __construct()
	{
		self::$con = mysqli_connect('localhost', 'root', '', 'movie-web');
	}

	public function checkAdminLoginInfo($data)
	{
		$data = json_decode($data);
		$return_data['success'] = '';
		$return_data['error'] = '';
		$return_data['message'] = '';


		$password = $this->convertForPassword($data->password);
		$query = 'SELECT * FROM wb_movie_admin_info  WHERE wb_admin_email_id = \''.$data->email.'\' AND wb_admin_password = \''.$password.'\' ';
		$query_result = mysqli_query(self::$con, $query);
		
		$count = $query_result->num_rows;
		$ans = mysqli_fetch_assoc($query_result);
		if ($count == 1) {
			if ($ans['wb_admin_is_status'] == 0) {
				$return_data['error'] = '1';
				$return_data['message'] = 'admin_is_block';
			} else {
				$return_data['success'] = '1';
				$email = $ans['wb_admin_username'];
				$email_encryp = $this->convertForCookie($email);
				$email_encryp = addslashes($email_encryp);
				
				if ($data->checkbox == 0) {
					$_SESSION[$email_encryp] = '1';
					setcookie('wb-movie-name-info', $email_encryp);
				} else {
					setcookie('wb-movie-name-info', $email_encryp, time()+365*24*60*60);
					$_SESSION[$email_encryp] = '1';
				}
			}
		} else {
			$return_data['error'] = '1';
			$return_data['message'] = 'no_record_found';
		}

		$return_data = json_encode($return_data);
		return $return_data;
	}

	public function selectMovieType($data)
	{
		$query = 'SELECT * FROM wb_movie_type  WHERE main_type_status = \'1\' ORDER BY main_type_position';
		$return_data = mysqli_query(self::$con, $query);
		return $return_data;
	}

	public function selectMovieList($data)
	{
		$data['limit'] = 21;
		$data['start'] = ($data['start'] != 0 ? (($data['start'] -1) * $data['limit']) : 0);
		$query = '';
		$query .= 'SELECT id_movie_info, movie_name, movie_sub_title, movie_description, movie_release_date, movie_entry_datetime, movie_link, id_movie_type, movie_is_status, movie_info_img FROM wb_movie_info';
		if (isset($data['id_movie_type']) && !empty($data['id_movie_type']))
		{
			$query .= ' AND id_movie_type='.$data['id_movie_type'].'';
		}

		if (isset($data['search']) && !empty($data['search']))
		{
			$query .= ' AND movie_name LIKE \'%'.$data['search'].'%\'';
		}

		$query .= ' ORDER BY movie_entry_datetime DESC';
		// $query .= ' LIMIT '.$data['start'].','.$data['limit'];

		$return_data = mysqli_query(self::$con, $query);
	
		return $return_data;
	}

	public function selectSliderList($data)
	{
		$data['limit'] = 21;
		$data['start'] = ($data['start'] != 0 ? (($data['start'] -1) * $data['limit']) : 0);
		$query = '';
		$query .= 'SELECT * FROM wb_slider';
		$query .= ' ORDER BY slider_entry_datetime DESC';
		$query .= ' LIMIT '.$data['start'].','.$data['limit'];

		$return_data = mysqli_query(self::$con, $query);
	
		return $return_data;
	}

	public function selectSliderList2($data)
	{
		$data['limit'] = 21;
		$data['start'] = ($data['start'] != 0 ? (($data['start'] -1) * $data['limit']) : 0);
		$query = '';
		$query .= 'SELECT * FROM wb_slider2';
		$query .= ' ORDER BY slider_entry_datetime DESC';
		$query .= ' LIMIT '.$data['start'].','.$data['limit'];

		$return_data = mysqli_query(self::$con, $query);
	
		return $return_data;
	}

	public function selectCustomerMessage($data)
	{
		$data['limit'] = 21;
		$data['start'] = ($data['start'] != 0 ? (($data['start'] -1) * $data['limit']) : 0);

		$query = 'SELECT * FROM wb_movie_customer_info';
		$query .= ' limit '.$data['start'].','.$data['limit'];
		$return_data = mysqli_query(self::$con, $query);

		return $return_data;
	}

	public function setPaginationInformation($data)
	{
		// same as limit   /******* $data['limit'] = 21; ***********/ as above function
		$show_total_list = 21;
		$query = '';
		$query .= 'SELECT COUNT(id_movie_info) as count FROM wb_movie_info';
		
		$check_search_page = false;
		if (isset($data['search']) && !empty($data['search']))
		{
			$query .= ' WHERE movie_name LIKE \'%'.$data['search'].'%\'';
			$check_search_page = true;
		}

		$return_data = mysqli_query(self::$con, $query);
		$ans = mysqli_fetch_array($return_data);
		$count = $ans['count'];

		$pagination_number = ceil($count/$show_total_list);
		return $pagination_number;
	}

	public function setPaginationSliderInformation($data)
	{
		// same as limit   /******* $data['limit'] = 21; ***********/ as above function
		$show_total_list = 21;
		$query = '';
		$query .= 'SELECT COUNT(id_slider) as count FROM wb_slider';
		
		$return_data = mysqli_query(self::$con, $query);
		$ans = mysqli_fetch_array($return_data);
		$count = $ans['count'];

		$pagination_number = ceil($count/$show_total_list);
		return $pagination_number;
	}

	public function setPaginationSliderInformation2($data)
	{
		// same as limit   /******* $data['limit'] = 21; ***********/ as above function
		$show_total_list = 21;
		$query = '';
		$query .= 'SELECT COUNT(id_slider) as count FROM wb_slider2';
		
		$return_data = mysqli_query(self::$con, $query);
		$ans = mysqli_fetch_array($return_data);
		$count = $ans['count'];

		$pagination_number = ceil($count/$show_total_list);
		return $pagination_number;
	}

	public function setPaginationCustomerInformation($data)
	{
		// same as limit   /******* $data['limit'] = 21; ***********/ as above function
		$show_total_list = 21;
		$query = '';
		$query .= 'SELECT COUNT(wb_movie_customer_id) as count FROM wb_movie_customer_info';
		
		$return_data = mysqli_query(self::$con, $query);
		$ans = mysqli_fetch_array($return_data);
		$count = $ans['count'];

		$pagination_number = ceil($count/$show_total_list);

		return $pagination_number;
	}

	public function selectSliderInformation($data)
	{
		$query = 'SELECT * FROM wb_slider WHERE slider_is_status = \'1\' ORDER BY slider_position ';
		$return_data = mysqli_query(self::$con, $query);
		return $return_data;
	}

	public function selectUpcommingMovie($data)
	{
		$query = 'SELECT * FROM wb_movie_info  WHERE movie_is_status = \'1\' ORDER BY movie_release_date ASC LIMIT '.$data['start'].','.$data['limit'];
		$return_data = mysqli_query(self::$con, $query);
		return $return_data;
	}

	public function selectFullMovieList($data)
	{
		$query = 'SELECT * FROM wb_movie_info WHERE id_movie_info='.$data['movie'];
		$return_data = mysqli_query(self::$con, $query);
		return $return_data;
	}

	public function selectMovieSliderImage($data)
	{
		$query = 'SELECT * FROM wb_movie_image WHERE id_movie_info='.$data['id_movie_info'];
		$return_data = mysqli_query(self::$con, $query);
		return $return_data;
	}

	public function convertForCookie($user_name)
	{
		$ans = md5($user_name);
		$ans = str_split($ans);
		$res = '';
		foreach($ans as $value) {
			$res_2 = md5($value);
			$res .= substr($res_2,10,27);
		}

		$ans = str_split($res);
		$res = '';
		foreach($ans as $value){
			$row = sha1($value, false);
			$i = substr($row, 27)."<br>";
			$res .= $i;
		}
		$ans = str_split($res);
		$count = count($ans);
		$res = '';
		$i = 0;
		while($i<=$count) {
			$res .= $ans[$i];
			$i = $i + 10;
		}

		$res = addslashes($res);
		return $res;
	}

	public function convertForPassword($password)
	{
		$password = sha1($password);
		$password = str_split($password);
		$return = '';
		foreach($password as $value)
		{
			$j = md5($value);
			$j = substr($j, 10, 27);
			$j = str_split($j);
			$return .= $j[10];
		}
		return $return;
	}


	public function checkCookie()
	{
		if (isset($_COOKIE['wb-movie-name-info'])) {
			$cookie = $_COOKIE['wb-movie-name-info'];
			if (isset($_SESSION[$cookie])) {
				return true;
			}
		}

		if (isset($_COOKIE['wb-movie-name-info'])) {
		    $ans = $_COOKIE['wb-movie-name-info'];
		    $ans = json_encode($ans); 
		    $ans = json_decode($ans);
		    $query = 'SELECT * FROM wb_movie_admin_info WHERE wb_admin_set_cookie = \''.$ans.'\'';
			$query_result = mysqli_query(self::$con, $query);
			$num_rows = $query_result->num_rows;
			if ($num_rows == '1') {
    			$ans = mysqli_fetch_assoc($query_result);
    			$cookie = $ans['wb_admin_set_cookie'];
    			$_SESSION[$cookie] = 1;
    			return true;
			}
			return false;
		}
		return false;
	}

	public function deleteMovie($id)
	{
		$query = 'DELETE FROM wb_movie_info WHERE id_movie_info='.$id;
		$return_data = mysqli_query(self::$con, $query);

		$query = 'DELETE FROM wb_movie_image WHERE id_movie_info='.$id;
		$return_data = mysqli_query(self::$con, $query);
		return $return_data;
	}

	public function deleteSlider($id)
	{
		$query = 'DELETE FROM wb_slider WHERE id_slider='.$id;
		$return_data = mysqli_query(self::$con, $query);
		return $return_data;
	}

	public function deleteSlider2($id)
	{
		$query = 'DELETE FROM wb_slider2 WHERE id_slider='.$id;
		$return_data = mysqli_query(self::$con, $query);
		return $return_data;
	}
	

	public function selectMovieTypeAsId()
	{
		$query = "SELECT id_movie_type, movie_type_title FROM wb_movie_type";
		$return_data = mysqli_query(self::$con, $query);

		$return_array = array();
		while($data = mysqli_fetch_assoc($return_data)) {
			$return_array[$data['id_movie_type']] = $data['movie_type_title'];
		}

		return $return_array;
	}


	public function selectFullMovieInformation($data)
	{	
		$return_data = array();
		if (empty($data)) {
			return $return_data;
		}
		$query = 'SELECT * FROM wb_movie_info WHERE id_movie_info = '.$data['id'];
		$return = mysqli_query(self::$con, $query);
		$return_data = mysqli_fetch_assoc($return);

		$query_2 = 'SELECT * FROM wb_movie_image WHERE id_movie_info = '.$return_data['id_movie_info'];
		$return_2 = mysqli_query(self::$con, $query_2);
		while($data_2 = mysqli_fetch_assoc($return_2)) {
			$return_data['slider_img'][] = $data_2;
		}
		return $return_data;
	}

	public function selectFullSliderInformation($data)
	{	
		$return_data = array();
		if (empty($data)) {
			return $return_data;
		}
		$query = 'SELECT * FROM wb_slider WHERE id_slider = '.$data['id'];
		$return = mysqli_query(self::$con, $query);
		$return_data = mysqli_fetch_assoc($return);

		return $return_data;
	}

	public function selectFullSliderInformation2($data)
	{	
		$return_data = array();
		if (empty($data)) {
			return $return_data;
		}
		$query = 'SELECT * FROM wb_slider2 WHERE id_slider = '.$data['id'];
		$return = mysqli_query(self::$con, $query);
		$return_data = mysqli_fetch_assoc($return);

		return $return_data;
	}

	public function selectSliderImageOfMovie($data)
	{
		$query = 'SELECT * FROM wb_movie_image WHERE id_movie_info = '.$data['movie_image_id'];
		$return_data = mysqli_query(self::$con, $query);
		return $return_data;
	}

	public function deleteMovieSliderImage($data)
	{
		$query = 'DELETE FROM wb_movie_image WHERE movie_image_id='.$data['id'];
		$return_data = mysqli_query(self::$con, $query);
		return $return_data;
	}

	public function checkProperImage($image)
	{
		$name = $image['name'];
		$type = $image['type'];
		$tmp_name = $image['tmp_name'];


		$error_msg = '';
		if ($type == 'image/jpeg') {
			$img_type = '.jpeg';
		} elseif ($type == 'image/jpg') {
			$img_type = '.jpg';
		} elseif ($type == 'image/png') {
			$img_type = '.png';
		} elseif ($type == 'image/gif') {
			$img_type = '.gif';
		} else {
			$error_msg = 'Please Select Proper Image';
		}
		$return_data['name'] = $image['name'];
		$return_data['type'] = $img_type;
		$return_data['error_msg'] = $error_msg;

		// echo "<pre>";
		// print_r($return_data);
		// exit;
		return $return_data;
	}

	public function insertMoviePosterImage($image)
	{
		$tmp_name = $image['tmp_name'];
		$data = $this->checkProperImage($image);
		if (empty($data['error_msg'])) {
			$date = date("Ymdhis");
			$new_name = $date.$data['type'];
			$destination_path = $_SERVER['CONTEXT_DOCUMENT_ROOT'].'/movie-web/images/movie-img/'.$new_name;
			if(move_uploaded_file($tmp_name, $destination_path)) {
				$return_data = $new_name;
				sleep(1);
			} else {
				$return_data = '';
			}

			// Return Name
			return $return_data;
		}
		return false;
	}

	public function insertSliderImage($image)
	{
		$data = $this->checkProperImage($image);
		if (empty($data['error_msg'])) {
			$date = date("Ymdhis");
			$new_name = $date.$data['type'];
			$destination_path = $_SERVER['CONTEXT_DOCUMENT_ROOT'].'/movie-web/images/slider-img/'.$new_name;
			if(move_uploaded_file($image['tmp_name'], $destination_path)) {
				$return_data = $new_name;
				sleep(1);
			} else {
				$return_data = '';
			}

			// Return Name
			return $return_data;
		}
		return false;
	}

	public function insertSliderImage2($image)
	{
		$data = $this->checkProperImage($image);
		if (empty($data['error_msg'])) {
			$date = date("Ymdhis");
			$new_name = $date.$data['type'];
			$destination_path = $_SERVER['CONTEXT_DOCUMENT_ROOT'].'/movie-web/images/slider-img2/'.$new_name;
			if(move_uploaded_file($image['tmp_name'], $destination_path)) {
				$return_data = $new_name;
				sleep(1);
			} else {
				$return_data = '';
			}

			// Return Name
			return $return_data;
		}
		return false;
	}

	public function selectMovieImage($id)
	{
		$query = 'SELECT movie_info_img as img FROM wb_movie_info WHERE id_movie_info='.$id;
		$return_data = mysqli_query(self::$con, $query);
		return $return_data['img'];
	}


	public function selectSliderImage($id)
	{
		$query = 'SELECT slider_img as img FROM wb_slider WHERE id_slider='.$id;
		$return_data = mysqli_query(self::$con, $query);
		return $return_data['img'];
	}

	public function selectSliderImage2($id)
	{
		$query = 'SELECT slider_img as img FROM wb_slider2 WHERE id_slider='.$id;
		$return_data = mysqli_query(self::$con, $query);
		return $return_data['img'];
	}

	

	public function insertMovieSliderImages($images)
	{
		$count = count($images['name']);

		$return_data = array();
		for($i=0;$i<$count;$i++) {
			$name = $images['name'][$i];
			$img_types = array('jpg','jpeg','gif','png');
			$img_type_show = explode('/',$images['type'][$i]);
			$tmp_name = $images['tmp_name'][$i];
			if (in_array($img_type_show[1], $img_types)) {
				$date = date("Ymdhis");
				$new_name = $date.'.'.$img_type_show[1];
		
				$destination_path = $_SERVER['CONTEXT_DOCUMENT_ROOT'].'/movie-web/images/movie-slider-img/'.$new_name;
				move_uploaded_file($tmp_name, $destination_path);
				$return_data[] = $new_name;
				sleep(1);
			}
		}
		// $return_data = mysqli_query(self::$con, $query);
		return $return_data;
	}

	public function insertMovieSliderImagesInTable($img_name, $id_movie_info = '')
	{
		if (!empty($img_name)) {
			if (!empty($id_movie_info)) {
				$id = $id_movie_info;
			} else {
				$id = $this->maxMovieId();
			}

			$query_list = array();
			foreach($img_name as $name) {
				$query_list[] = 'INSERT INTO wb_movie_image 
					SET 
						movie_image_id = NULL,
						id_movie_info = '.$id.',
						movie_image_name = \''.$name.'\',
						movie_image_link = \'#\',
						movie_image_is_status =\'1\'';
			}
			foreach($query_list as $query) {
				mysqli_query(self::$con, $query);
			}
		}
	}

	public function maxMovieId()
	{
		$query = 'SELECT MAX(id_movie_info) as id FROM wb_movie_info';
		$return_data = mysqli_query(self::$con, $query);
		$return_data = mysqli_fetch_assoc($return_data);
		$return_data = $return_data['id'];
		return $return_data;
	}

	public function maxMainSliderId()
	{
		$query = 'SELECT MAX(id_slider) as id FROM wb_slider';
		$return_data = mysqli_query(self::$con, $query);
		$return_data = mysqli_fetch_assoc($return_data);
		$return_data = $return_data['id'];
		return $return_data;
	}

	public function maxMainSliderId2()
	{
		$query = 'SELECT MAX(id_slider) as id FROM wb_slider2';
		$return_data = mysqli_query(self::$con, $query);
		$return_data = mysqli_fetch_assoc($return_data);
		$return_data = $return_data['id'];
		return $return_data;
	}

	public function uploadLinkFile($file)
	{
		$name = $file['name'];
		$tmp_name = $file['tmp_name'];
		$date = date("Ymdhis");
		$tmp_ext_list = explode('.', $name);
		$extension = end($tmp_ext_list);
		$new_name = $date.'.'.$extension;
		$destination_path = $_SERVER['CONTEXT_DOCUMENT_ROOT'].'/movie-web/upload-link-file/'.$new_name;
		move_uploaded_file($tmp_name, $destination_path);
		sleep(1);
		return $new_name;
	}


	public function updateSliderInformation($data)
	{
		$entry_date = date('Y-m-d\TH:i:s');
		$query = 'UPDATE wb_movie_info 
			SET
				movie_name = \''.$data['movie_name'].'\',
				movie_full_name = \''.$data['movie_full_name'].'\',
				movie_sub_title = \''.$data['movie_sub_title'].'\',
				movie_sub_title_2 = \''.$data['movie_sub_title_2'].'\',
				movie_genres = \''.$data['movie_genres'].'\',
				movie_language = \''.$data['movie_language'].'\',
				movie_size = \''.$data['movie_size'].'\',
				movie_quality = \''.$data['movie_quality'].'\',
				movie_description = \''.$data['movie_description'].'\',
				movie_meta_title = \''.$data['movie_meta_title'].'\',
				movie_meta_description = \''.$data['movie_meta_description'].'\',
				movie_release_date = \''.$data['movie_release_date'].'\',
				movie_link = \''.$data['movie_link'].'\',
				id_movie_type = \''.$data['id_movie_type'].'\',
				movie_is_status = \''.$data['movie_is_status'].'\',
				
				movie_story_line = \''.$data['movie_story_line'].'\',
				movie_story_details = \''.$data['movie_story_details'].'\',
				movie_trailer_link = \''.$data['movie_trailer_link'].'\',
				movie_final_link = \''.$data['movie_final_link'].'\',
				movie_cast = \''.$data['movie_cast'].'\'';

		if (!empty($data['movie_info_img'])) {
			$query .= ',movie_info_img	 = \''.$data['movie_info_img'].'\'';
		}

		if (!empty($data['movie_info_img_2'])) {
			$query .= ',movie_info_img_2	 = \''.$data['movie_info_img_2'].'\'';
		}

		if (!empty($data['movie_link_file'])) {
			$query .= ',movie_link_file	 = \''.$data['movie_link_file'].'\'';
		}

		$query .= ' WHERE id_movie_info = '.$data['id_movie_info'];
		$query_result = mysqli_query(self::$con, $query);
		return $query_result;
	}

	public function insertSliderInformation($data)
	{
		$id = $this->maxMovieId();
		$id = $id + 1;
		$entry_date = date('Y-m-d\TH:i:s');
		$query = 'INSERT INTO wb_movie_info 
			SET
				id_movie_info = '.$id.',
				movie_name = \''.$data['movie_name'].'\',
				movie_full_name = \''.$data['movie_full_name'].'\',
				movie_sub_title = \''.$data['movie_sub_title'].'\',
				movie_sub_title_2 = \''.$data['movie_sub_title_2'].'\',
				movie_genres = \''.$data['movie_genres'].'\',
				movie_language = \''.$data['movie_language'].'\',
				movie_size = \''.$data['movie_size'].'\',
				movie_quality = \''.$data['movie_quality'].'\',
				movie_description = \''.$data['movie_description'].'\',
				movie_meta_title = \''.$data['movie_meta_title'].'\',
				movie_meta_description = \''.$data['movie_meta_description'].'\',
				movie_release_date = \''.$data['movie_release_date'].'\',
				movie_entry_datetime = \''.$entry_date.'\',
				movie_position = '.$id.',
				movie_link = \''.$data['movie_link'].'\',
				id_movie_type = \''.$data['id_movie_type'].'\',
				movie_is_status = \''.$data['movie_is_status'].'\',
				movie_info_img	 = \''.$data['movie_info_img'].'\',
				movie_info_img_2	 = \''.$data['movie_info_img_2'].'\',
				movie_story_line = \''.$data['movie_story_line'].'\',
				movie_story_details = \''.$data['movie_story_details'].'\',
				movie_trailer_link = \''.$data['movie_trailer_link'].'\',
				movie_final_link = \''.$data['movie_final_link'].'\',
				movie_cast = \''.$data['movie_cast'].'\',
				movie_link_file = \''.$data['movie_link_file'].'\'';

		$query_result = mysqli_query(self::$con, $query);
		return $query_result;
	}


	public function updateMainSliderInformation($data)
	{
		$entry_date = date('Y-m-d\TH:i:s');
		$query = 'UPDATE wb_slider 
			SET
				slider_name = \''.$data['slider_name'].'\',
				slider_link = \''.$data['slider_link'].'\',
				slider_position = \'\',
				slider_is_status = \''.$data['slider_is_status'].'\'';

		if (!empty($data['slider_img'])) {
			$query .= ',slider_img	 = \''.$data['slider_img'].'\'';
		}

		$query .= ' WHERE id_slider = '.$data['id_slider'];
		$query_result = mysqli_query(self::$con, $query);
		return $query_result;
	}

	public function updateMainSliderInformation2($data)
	{
		$entry_date = date('Y-m-d\TH:i:s');
		$query = 'UPDATE wb_slider2 
			SET
				slider_name = \''.$data['slider_name'].'\',
				slider_link = \''.$data['slider_link'].'\',
				slider_position = \'\',
				slider_is_status = \''.$data['slider_is_status'].'\'';

		if (!empty($data['slider_img'])) {
			$query .= ',slider_img	 = \''.$data['slider_img'].'\'';
		}

		$query .= ' WHERE id_slider = '.$data['id_slider'];
		$query_result = mysqli_query(self::$con, $query);
		return $query_result;
	}

	public function insertMainSliderInformation($data)
	{
		$id = $this->maxMainSliderId();
		$id = $id + 1;
		$entry_date = date('Y-m-d\TH:i:s');
		$query = 'INSERT INTO wb_slider 
			SET
				id_slider = '.$id.',
				slider_name = \''.$data['slider_name'].'\',
				slider_link = \''.$data['slider_link'].'\',
				slider_img = \''.$data['slider_img'].'\',
				slider_position = \'\',
				slider_entry_datetime = \''.$entry_date.'\',
				slider_is_status = \''.$data['slider_is_status'].'\'';

		$query_result = mysqli_query(self::$con, $query);
		return $query_result;
	}

	public function insertMainSliderInformation2($data)
	{
		$id = $this->maxMainSliderId2();
		$id = $id + 1;
		$entry_date = date('Y-m-d\TH:i:s');
		$query = 'INSERT INTO wb_slider2 
			SET
				id_slider = '.$id.',
				slider_name = \''.$data['slider_name'].'\',
				slider_link = \''.$data['slider_link'].'\',
				slider_img = \''.$data['slider_img'].'\',
				slider_position = \'\',
				slider_entry_datetime = \''.$entry_date.'\',
				slider_is_status = \''.$data['slider_is_status'].'\'';

		$query_result = mysqli_query(self::$con, $query);
		return $query_result;
	}


	

	public function insertData()
	{
		$user_name = 'kishandholakiya@1027';
		$password = 'kishan';
		$pass = $this->convertForPassword($password);
		$cookie = $this->convertForCookie($user_name);
		
		// wb_admin_id is must be null
		$query = 'INSERT INTO wb_movie_admin_info
        SET 
            wb_admin_id = 1, 
            wb_admin_name = "Kishan",
            wb_admin_surname = "Dholakiya",
            wb_admin_username = "'.$user_name.'",
            wb_admin_email_id = "k.dholakiya@gmail.com",
            wb_admin_password = "'.$pass.'",
            wb_admin_ip_address = "2405:204:8080:e512:5911:a567:291d:41c7",
            wb_admin_is_status = "1",
            wb_admin_set_cookie = "'.$cookie.'"';
		$query_result = mysqli_query(self::$con, $query);
		return $query_result;
	}
}

$connection = new Connection();
