<?php include_once('connection.php'); 

$check_login = $connection->checkCookie();
if (!$check_login) {
    header("Location:index.php");
}

if (isset($_GET['delete-movie-id']) && !empty($_GET['delete-movie-id'])) {
	$del_id = $_GET['delete-movie-id'];
	$res = $connection->deleteMovie($del_id);
	if ($res) {
		header("Location:movie-list.php?del-id=confirm");
	} else {
		header("Location:movie-list.php?del-id=not-confirm");
	}
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <title>Ela - Bootstrap Admin Dashboard Template</title>
    <!-- Bootstrap Core CSS -->
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:** -->
    <!--[if lt IE 9]>
    <script src="https:**oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https:**oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body class="fix-header fix-sidebar">
    <!-- Preloader - style you can find in spinners.css -->
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
			<circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>
    <!-- Main wrapper  -->
    <div id="main-wrapper">
        <?php include_once("header.php"); ?>
        <!-- End header header -->
        <!-- Left Sidebar  -->
        <?php include_once("left_panel.php"); ?>
        <!-- End Left Sidebar  -->
        <!-- Page wrapper  -->
        <div class="page-wrapper">
            <div class="container-fluid">
                <!-- Start Page Content -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Movie List </h4>
                                <h6 class="card-subtitle">Show all movie Information</h6>

                                <h5> For Add New Movie Information <a href="add-edit-movie-info.php"><button>Click Here</button></a></h5>

                                <?php
                                $html = '';
                                if (isset($_GET['del-id']) && !empty($_GET['del-id']))
                                {
                                	if ($_GET['del-id'] == 'confirm') {
                                		$html .= 'Movie is Deleted';
                                	}elseif ($_GET['del-id'] == 'not-confirm') {
                                		$html .= 'Movie is Not Deleted';
                                	}
                                }
                                echo '<p>'.$html.'</p>';
                                ?>

                                <div class="table-responsive m-t-40">
                                    <table id="example" class="table display table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>Status</th>
                                                <th>Name</th>
                                                <th>Movie Type</th>
                                                <th>Entry Date</th>
                                                <th>Release Date</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>

                                        <tbody>

                                        <?php 
                                        $data = array();
                                        // echo $_GET['page'];
                                        $data['start'] = (isset($_GET['page']) && !empty($_GET['page']) ? $_GET['page'] : 1);

                                        $movie_type_array = $connection->selectMovieTypeAsId();
                                        $return = $connection->selectMovieList($data); 
                                        $html = '';
                                        while ($ans = mysqli_fetch_assoc($return)) {
                                    		$status = ($ans['movie_is_status'] == '1' ? 'green.png' : 'red.png');
                                    		$id = $ans['id_movie_info'];
                                    		$name = $ans['movie_name'];
                                    		$movie_type = $ans['id_movie_type'];

                                    		$timestamp = strtotime($ans['movie_entry_datetime']); 
											$new_date = date('M d,Y', $timestamp);
                                    		$entry_date= $new_date;

											$timestamp = strtotime($ans['movie_release_date']); 
											$new_date = date('M d,Y', $timestamp);           		
                                    		$release_date = $new_date;

                                        	$html .= '
                                        	<tr>
                                                <td><img src=\'images/'.$status.'\' ></td>
                                                <td>'.$name.'</td>
                                                <td>'.$movie_type_array[$movie_type].'</td>
                                                <td>'.$entry_date.'</td>
                                                <td>'.$release_date.'</td>
                                                <td><a href=\'add-edit-movie-info.php?id='.$id.'\'>Edit</a><a href=\'movie-list.php?delete-movie-id='.$id.'\' onClick=\'return checkDelMovie();\'>Delete</a></td>
                                            </tr>
                                            ';
                                        }

                                        echo $html;
                                        ?>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- End PAge Content -->
            </div>
            
        </div>
        <!-- End Page wrapper  -->
    </div>
    <!-- End Wrapper -->
    <!-- All Jquery -->
    <style src="css/dataTables.bootstrap.css"></style>

    <script src="js/lib/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->

    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>

    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.bootstrap.js"></script>
    <script src="js/tables.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Menu sidebar -->
    <script src="js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <!--Custom JavaScript -->
    <script src="js/scripts.js"></script>

<script>
	// $(document).ready(function(){
	// 	$('.movie-list-del-movie').click(function(e){
	// 		e.preventDefault();
	// 		var check_movie_delete = confirm('Are you want to sure Delete Movie?');
	// 		if (check_movie_delete == true) {
	// 			return true;
	// 		} else {
	// 			return false;
	// 		}
	// 	});
	// });

function checkDelMovie()
{
	var del_movie_confirm = confirm('Are you want to sure Delete Movie?');
	if (del_movie_confirm == true) {
		return true;
	} else {
		return false;
	}
}
</script>

</body>

</html>