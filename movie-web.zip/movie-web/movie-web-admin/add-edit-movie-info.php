<?php include_once('connection.php'); 

if (isset($_POST['update_form'])) {

	$data['id_movie_info'] = $_POST['id_movie_info'];
	$data['movie_name'] = addslashes($_POST['movie_name']);
	$data['movie_full_name'] = addslashes($_POST['movie_full_name']);
	$data['movie_sub_title'] = addslashes($_POST['movie_sub_title']);
	$data['movie_sub_title_2'] = addslashes($_POST['movie_sub_title_2']);
	$data['movie_genres'] = addslashes($_POST['movie_genres']);
	$data['movie_language'] = addslashes($_POST['movie_language']);
	$data['movie_size'] = addslashes($_POST['movie_size']);
	$data['movie_quality'] = addslashes($_POST['movie_quality']);
	$data['movie_release_date'] = addslashes($_POST['movie_release_date']);

	$link = implode('#$%^&*()', $_POST['movie_link']);
	$data['movie_link'] = addslashes($link);

	$data['movie_description'] = addslashes($_POST['movie_description']);
	$data['movie_meta_title'] = addslashes($_POST['movie_meta_title']);
	$data['movie_meta_description'] = addslashes($_POST['movie_meta_description']);
	$data['movie_story_line'] = addslashes($_POST['movie_story_line']);
	$data['movie_story_details'] = addslashes($_POST['movie_story_details']);
	$data['id_movie_type'] = addslashes($_POST['id_movie_type']);


	$actor_count = count($_POST['actor_name']);
	$actor_info = $_POST['actor_name'];
	$cast_info = $_POST['role_name'];
	$seprater = false;
	$movie_cast = '';
	for($i=0;$i<$actor_count;$i++)
	{
		if ($seprater == false) {
			$seprater = true;
		} else{
			$movie_cast .= '###@@@';
		}

		$movie_cast .= $actor_info[$i].'***+++'.$cast_info[$i];
	}
	sleep(1);
	$data['movie_cast'] = addslashes($movie_cast);

	$data['movie_is_status'] = (isset($_POST['movie_is_status']) && $_POST['movie_is_status'] == 'on' ? '1' : '0');


	$movie_info_img = '';	
	if (isset($_FILES['movie_info_img']['name']) && !empty($_FILES['movie_info_img']['name'])) {
		$image = $_FILES['movie_info_img'];
		
		$movie_info_img = $connection->insertMoviePosterImage($image);
	
		if ($movie_info_img == false) {
			$select_movie_img = $connection->selectMovieImage($data['id_movie_info']);
		}
	}
	$data['movie_info_img'] = $movie_info_img;

	$movie_info_img_2 = '';
	if (isset($_FILES['movie_info_img_2']['name']) && !empty($_FILES['movie_info_img_2']['name'])) {
		$image = $_FILES['movie_info_img_2'];
		$movie_info_img_2 = $connection->insertMoviePosterImage($image);
		if ($movie_info_img_2 == false) {
			$select_movie_img = $connection->selectMovieImage($data['id_movie_info']);
		}
	}
	$data['movie_info_img_2'] = $movie_info_img_2;


	$data['movie_trailer_link'] = addslashes($_POST['movie_trailer_link']);
	$data['movie_final_link'] = addslashes($_POST['movie_final_link']);


	$file_name = '';
	if (isset($_FILES['movie_link_file']['name']) && !empty($_FILES['movie_link_file']['name'])) {
		$file = $_FILES['movie_link_file'];
		$file_name = $connection->uploadLinkFile($file);
		$data['movie_link_file'] = $file_name;
	}


	$return_data = $connection->updateSliderInformation($data);
		

	$images = $_FILES['Slider-Images'];
	$data['movie_slider_img'] = $connection->insertMovieSliderImages($images);
	$connection->insertMovieSliderImagesInTable($data['movie_slider_img'], $data['id_movie_info']);
	header("Location:movie-list.php");
}


if (isset($_POST['add_form'])) {	
	$data['movie_name'] = addslashes($_POST['movie_name']);
	$data['movie_full_name'] = addslashes($_POST['movie_full_name']);
	$data['movie_sub_title'] = addslashes($_POST['movie_sub_title']);
	$data['movie_sub_title_2'] = addslashes($_POST['movie_sub_title_2']);
	$data['movie_genres'] = addslashes($_POST['movie_genres']);
	$data['movie_language'] = addslashes($_POST['movie_language']);
	$data['movie_size'] = addslashes($_POST['movie_size']);
	$data['movie_quality'] = addslashes($_POST['movie_quality']);
	$data['movie_release_date'] = addslashes($_POST['movie_release_date']);
	
	$link = implode('#$%^&*()', $_POST['movie_link']);
	$data['movie_link'] = addslashes($link);

	$data['movie_description'] = addslashes($_POST['movie_description']);
	$data['movie_meta_title'] = addslashes($_POST['movie_meta_title']);
	$data['movie_meta_description'] = addslashes($_POST['movie_meta_description']);
	$data['movie_story_line'] = addslashes($_POST['movie_story_line']);
	$data['movie_story_details'] = addslashes($_POST['movie_story_details']);
	$data['id_movie_type'] = addslashes($_POST['id_movie_type']);

	$actor_count = count($_POST['actor_name']);
	$actor_info = $_POST['actor_name'];
	$cast_info = $_POST['role_name'];
	$seprater = false;
	$movie_cast = '';
	for($i=0;$i<$actor_count;$i++)
	{
		if ($seprater == false) {
			$seprater = true;
		} else{
			$movie_cast .= '###@@@';
		}

		$movie_cast .= $actor_info[$i].'***+++'.$cast_info[$i];
	}
	$data['movie_cast'] = addslashes($movie_cast);
	$data['movie_is_status'] = (isset($_POST['movie_is_status']) && $_POST['movie_is_status'] == 'on' ? '1' : '0');

	
	$file_name = '';
	if (isset($_FILES['movie_link_file']['name']) && !empty($_FILES['movie_link_file']['name'])) {
		$file = $_FILES['movie_link_file'];
		$file_name = $connection->uploadLinkFile($file);
	}
	$data['movie_link_file'] = $file_name;

	
	// $image = $_FILES['movie_info_img'];
	$file_name = '';
	if (isset($_FILES['movie_info_img']['name']) && !empty($_FILES['movie_info_img']['name'])) {
		$file = $_FILES['movie_info_img'];
		$file_name = $connection->insertMoviePosterImage($file);
	}
	$data['movie_info_img'] = $file_name;



	// $image = $_FILES['movie_info_img_2'];
	$file_name = '';
	if (isset($_FILES['movie_info_img_2']['name']) && !empty($_FILES['movie_info_img_2']['name'])) {
		$file = $_FILES['movie_info_img_2'];
		$file_name = $connection->insertMoviePosterImage($file);
	}
	$data['movie_info_img_2'] = $file_name;

	$data['movie_trailer_link'] = addslashes($_POST['movie_trailer_link']);
	$data['movie_final_link'] = addslashes($_POST['movie_final_link']);


	// insert full movie information
	$return_data = $connection->insertSliderInformation($data);


	// insert Movie Slider information
	$images = $_FILES['Slider-Images'];
	$data['movie_slider_img'] = $connection->insertMovieSliderImages($images);
	$connection->insertMovieSliderImagesInTable($data['movie_slider_img']);
	header("Location:movie-list.php");
}



?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Movie Post Form</title>

<link href="css/post-style.css" rel="stylesheet" type="text/css"/>
</head>

<body>
<form class="movie-data-form" method="post" action="add-edit-movie-info.php" enctype="multipart/form-data">
	<table border="0" cellpadding="20" cellspacing="20" class="post-box">
		<thead >
			<?php
			$title = ((isset($_GET['id']) && !empty($_GET['id'])) ? 'Movie Edit' : 'Movie Add'); ?>
			<label style="text-align: center;"><h1><?php echo $title; ?></h1></label>
		</thead>

		<?php 
		
		$data['id'] = (isset($_GET['id']) && !empty($_GET['id']) ? $_GET['id'] : '');

		$return_data = '';
		if ($data['id'] != '') {
			$return_data = $connection->selectFullMovieInformation($data); ?>
			<input type='hidden' name='id_movie_info' value='<?php echo $return_data['id_movie_info']; ?>'> <?php 
		} ?>

		<tbody>
			<tr>
				<td><label>Name :-</label></td>
				<td>
				<?php $tmp = (!empty($return_data) ? $return_data['movie_name'] : '');  ?>
					<input class="box" type="text" name="movie_name" id="#1" placeholder="Enter Your Movie Title" value="<?php echo $tmp; ?>">
				</td>
			</tr>


			<tr>
				<td><label>Movie date and time:-</label></td>
				<td>
					<?php $tmp = (!empty($return_data) ? $return_data['movie_release_date'] : '');

					$tmp = '';
					if (!empty($return_data)) {
						$timestamp = strtotime($return_data['movie_release_date']); 

						$tmp = date('Y-m-d\TH:i:s', $timestamp);
					} ?>
					<input class="box" type="datetime-local" name="movie_release_date" placeholder="date and time" value='<?php echo $tmp; ?>'>
				</td>
			</tr>

			<tr>
				<!-- Movie Description  -->
				<td><label>Movie Content 1 :-</label></td>
				<td>
				<?php $tmp = (!empty($return_data) ? $return_data['movie_description'] : '');  ?>
					<input class="box" type="text" name="movie_description" placeholder="Enter Your Movie Description" value="<?php echo $tmp; ?>">
				</td>
			</tr>

			<tr>
				<!-- Movie Description  -->
				<td><label>Meta Title :-</label></td>
				<td>
				<?php $tmp = (!empty($return_data) ? $return_data['movie_meta_title'] : '');  ?>
					<input class="box" type="text" name="movie_meta_title" placeholder="Enter Your Meta Title" value="<?php echo $tmp; ?>">
				</td>
			</tr>

			<tr>
				<!-- Movie Description  -->
				<td><label>Meta Description :-</label></td>
				<td>
				<?php $tmp = (!empty($return_data) ? $return_data['movie_meta_description'] : '');  ?>
					<input class="box" type="text" name="movie_meta_description" placeholder="Enter Your Meta Description" value="<?php echo $tmp; ?>">
				</td>
			</tr>



			<!-- <tr>
				<td><label>Sub title 1 :-</label></td>
				<td>
				<?php $tmp = (!empty($return_data) ? $return_data['movie_sub_title'] : '');  ?>
					<input class="box" type="text" name="movie_sub_title" placeholder="Enter Your Movie Sub-Title" value="<?php echo $tmp; ?>">
				</td>
			</tr> -->


			<!-- <tr>
				<td><label>Sub title 2 :-</label></td>
				<td>
				<?php $tmp = (!empty($return_data) ? $return_data['movie_sub_title_2'] : '');  ?>
					<input class="box" type="text" name="movie_sub_title_2" placeholder="Enter Your Movie Sub-Title 2" value="<?php echo $tmp; ?>">
				</td>
			</tr> -->	

				


			<tr>
				<td><label>Poster Image 1 :- </label></td>
				<td>
					<input type="file" name="movie_info_img">
					<?php $tmp = (!empty($return_data) ? $return_data['movie_info_img'] : ''); 
					$html = '';
					if (!empty($tmp)) {
						$html .= '<img src=\''.BASE_CLIENT_URL.'images/movie-img/'.$tmp.'\' width=\'50%\'>';
					}
					echo $html; ?>
				</td>
			</tr>


			<tr>
				<td><label>Movie Full Name :-</label></td>
				<td>
				<?php $tmp = (!empty($return_data) ? $return_data['movie_full_name'] : '');  ?>
					<input class="box" type="text" name="movie_full_name" id="#1" placeholder="Enter Movie Full Name" value="<?php echo $tmp; ?>">
				</td>
			</tr>

			<tr>
				<td><label>Movie Genres :- </label></td>
				<td>
				<?php $tmp = (!empty($return_data) ? $return_data['movie_genres'] : '');  ?>
					<input class="box" type="text" name="movie_genres" id="#1" placeholder="Enter Movie Genres" value="<?php echo $tmp; ?>">
				</td>
			</tr>

			<tr>
				<td><label>Movie Language :- </label></td>
				<td>
				<?php $tmp = (!empty($return_data) ? $return_data['movie_language'] : '');  ?>
					<input class="box" type="text" name="movie_language" id="#1" placeholder="Enter Movie Genres" value="<?php echo $tmp; ?>">
				</td>
			</tr>

			<tr>
				<td><label>Movie Size :- </label></td>
				<td>
				<?php $tmp = (!empty($return_data) ? $return_data['movie_size'] : '');  ?>
					<input class="box" type="text" name="movie_size" id="#1" placeholder="Enter Movie Genres" value="<?php echo $tmp; ?>">
				</td>
			</tr>

			<tr>
				<td><label>Movie Quality :- </label></td>
				<td>
				<?php $tmp = (!empty($return_data) ? $return_data['movie_quality'] : '');  ?>
					<input class="box" type="text" name="movie_quality" id="#1" placeholder="Enter Movie Genres" value="<?php echo $tmp; ?>">
				</td>
			</tr>

			<tr>
				<td><label>Storyline Text :-</label></td>
				<td>
				<?php $tmp = (!empty($return_data) ? $return_data['movie_story_line'] : '');  ?>
					<input class="box" type="text" name="movie_story_line" placeholder="Enter Your Movie Description" value="<?php echo $tmp; ?>">
				</td>
			</tr>

			<tr>
				<td><label>Movie Story Details :-</label></td>
				<td>
				<?php $tmp = (!empty($return_data) ? $return_data['movie_story_details'] : '');  ?>
					<input class="box" type="text" name="movie_story_details" placeholder="Enter Your Movie Description" value="<?php echo $tmp; ?>">
				</td>
			</tr>

			<!-- <tr>
				<td><label>Poster Image 2:- </label></td>
				<td>
					<input type="Link" name="movie_info_img_2">
					<?php //$tmp = (!empty($return_data) ? $return_data['movie_info_img_2'] : ''); 
					// $html = '';
					// if (!empty($tmp)) {
					// 	$html .= '<img src=\''.BASE_CLIENT_URL.'images/movie-img/'.$tmp.'\' width=\'50%\'>';
					// }
					// echo $html; ?>
				</td>
			</tr> -->

			<tr>
				<td><label>Movie Trailer Link :-</label></td>
				<td>
				<?php $tmp = (!empty($return_data) ? $return_data['movie_trailer_link'] : '');  ?>
					<input class="box" type="text" name="movie_trailer_link" placeholder="Enter Movie Trailer Link" value="<?php echo $tmp; ?>">
				</td>
			</tr>

			<tr>
				<td><label>Movie Final Link :-</label></td>
				<td>
				<?php $tmp = (!empty($return_data) ? $return_data['movie_final_link'] : '');  ?>
					<input class="box" type="text" name="movie_final_link" placeholder="Enter Movie Fianl Link" value="<?php echo $tmp; ?>">
				</td>
			</tr>

			

			<!-- <tr>
				<td><label>Upload File</label></td>
				<td>
					<input type="file" name="movie_link_file">
					<?php // $tmp = (!empty($return_data) ? $return_data['movie_link_file'] : ''); 
					// $file_name = BASE_CLIENT_URL.'upload-link-file/'.$tmp;

					// $html = '';
					// if (!empty($tmp)) {
					// 	$html .= '<div><a href=\''.$file_name.'\' download=\''.$tmp.'\'>Download File</a></div>';
					// }
					// echo $html; ?>
				</td>
			</tr> -->

			<tr>
				<td><label>Select:-</label></td>
				<td>
					<select name='id_movie_type'>
					<?php 
					$return = $connection->selectMovieTypeAsId();
					$html = '';

					$tmp = (!empty($return_data) ? $return_data['id_movie_type'] : ''); 
					foreach ($return as $id=>$name) {
						$class = '';
						if ($tmp != '' && $id == $return_data['id_movie_type']) {
							$class .= 'selected=\'selected\'';
						}
						if ($id != 5) {
							$html .= '<option value=\''.$id.'\' '.$class.'>'.$name.'</option>';
						}
					}
					echo $html; ?>
	  	  			</select>
				</td>
			</tr>


			<tr>
				<td><label>Slider Images :-</label></td>
				<td>
					<input type="file" name="Slider-Images[]" multiple="multiple" class="select-slider-image">
					<?php  
					$data['movie_image_id'] = (!empty($return_data) ? $return_data['id_movie_info'] : ''); 
					$return = $connection->selectSliderImageOfMovie($data);
					$html = '';
					if (!empty($return_data) && $return == true) {
						while($ans = mysqli_fetch_assoc($return)) {
							$tmp = $ans['movie_image_name'];
							$del_id = $ans['movie_image_id'];
							$html .= '
								<div class=\'movie-slider-img-info\'>
									<div>
										<img src=\''.BASE_CLIENT_URL.'images/movie-slider-img/'.$tmp.'\' width=\'30%\'>
									</div>
									<a href=\'#\' class=\'movie-slider-img-delete\'  data-delete-img-name=\''.$tmp.'\' data-delete-id=\''.$del_id.'\'>Delete Image</a>
								</div>';
						}
					}
					echo $html; ?>
				</td>
			</tr>

			<tr>
				<td><label>Movie Cast</label></td>
				<td>
					<div class="movie-cast-wrapper">
						<?php $tmp = (!empty($return_data) ? $return_data['movie_cast'] : '');

						$html = '';
						if (!empty($tmp)) {
							$all_list = explode('###@@@', $tmp);
							foreach($all_list as $list) {
								$cast = explode('***+++', $list);
								$html .= '<div class="movie-cast-information" style="display:inline-flex;">
									<input placeholder="Enter Actor Name" type="textbox" class="box" name="actor_name[]" value="'.$cast[0].'" style="width:50%;display:inline-box;">
									<input placeholder="Enter Role Name" type="textbox" class="box" name="role_name[]" value="'.$cast[1].'" style="width:50%;display:inline-box;margin-left:30px;">
									<div class="remove-movie-cast" style="margin-left:30px;"><a href="#">Remove Cast</a></div>
								</div>';
							}

						} else {
							$html .= '<div class="movie-cast-information" style="display:inline-flex;">
								<input placeholder="Enter Actor Name" type="textbox" class="box" name="actor_name[]" value="" style="width:50%;display:inline-box;">
								<input placeholder="Enter Role Name" type="textbox" class="box" name="role_name[]" value="" style="width:50%;display:inline-box;margin-left:30px;">
								<div class="remove-movie-cast" style="margin-left:30px;"><a href="#">Remove Cast</a></div>
							</div>';
						}
						echo $html; ?>
					</div>
					<div class="add-movie-cast">
						<a href="#">Add New Cast</a>
					</div>
				</td>
			</tr>

			<tr>
				<td><label>Movie Link:-</label></td>
				<td>
					<div class="movie-link-wrapper">
					<?php $tmp = (!empty($return_data) ? $return_data['movie_link'] : '');  
					$html = '';
					if (!empty($tmp)) {
						$links = explode('#$%^&*()', $tmp);
						// print_r($links);
						foreach($links as $link) {
							$html .= '<div class="movie-link-info" style="display:inline-box">
								<input class="box" type="text" name="movie_link[]" placeholder="Enter Your Movie Link" style="width:70%;" value="'.$link.'">
								<a href="#">Remove Link</a>
							</div>';
						}
					} else {
						$html .= '<div class="movie-link-info" style="display:inline-box">
							<input class="box" type="text" name="movie_link[]" placeholder="Enter Your Movie Link" style="width:70%;">
							<a href="#">Remove Link</a>
						</div>';
					} 
					echo $html;?>
					</div>
					<div class="add-movie-link"><a href="#">Add Link</a></div>
				</td>
			</tr>

			<tr>
				<td><label>Image Status</label></td>
				<td>
					<?php $tmp = (!empty($return_data) ? $return_data['movie_is_status'] : ''); ?>
					<input type="checkbox" name="movie_is_status" <?php echo ($tmp == '1' ? 'checked=\'checked\'' : ''); ?>>
				</td>
			</tr>


			<tr>
				<td colspan="2">
					<input class="submit" type="submit" name="<?php echo (!empty($return_data) ? 'update_form' : 'add_form'); ?>" value="Submit">
				</td>
			</tr>
		</tbody>
	</table>
</form>


<script src="js/lib/jquery/jquery.min.js"></script>
<script src="js/form-validation.js"></script>
<script>
$(document).ready(function(){
	$('.movie-slider-img-info a.movie-slider-img-delete').click(function(e){
		e.preventDefault();
		var id = $(this).attr('data-delete-id');
		var name = $(this).attr('data-delete-img-name');
		var confirm_msg = confirm('Are you want to sure Delete This Slider image?');
		var obj = $(this).parent();
		if (confirm_msg == true && id != '') {
			$.ajax({
		        type: 'GET',
		        url: 'delete-movie-slider-img.php?id='+id+'&name='+name,
		        cache: false,
		        success: function(data)
		        {
		        	if (data == 'right') {
		        		obj.remove();
		        	} else {
		        		alert('Server error is accour');
		        	}
		        },
		        error: function(jqXHR, textStatus, errorThrown) {
		            console.log(textStatus, errorThrown);
		        }
		    });
		}
	});


	$('.add-movie-cast a').click(function(e){
		e.preventDefault();
		var html = '<div class="movie-cast-information" style="display:inline-flex;"><input placeholder="Enter Role Name" type="textbox" class="box" name="actor_name[]" value="" style="width:50%;display:inline-box;"><input placeholder="Enter Role Name" type="textbox" class="box" name="role_name[]" value="" style="width:50%;display:inline-box;margin-left:30px;"><div class="remove-movie-cast" style="margin-left:30px;"><a href="#">Remove Cast</a></div></div></div>';
		$('.movie-cast-wrapper').append(html);
	});

	$(document).on('click','.remove-movie-cast',function(e){
		e.preventDefault();
		$(this).parent().remove();
	});



	$('.add-movie-link a').click(function(e){
		e.preventDefault();
		var html = '<div class="movie-link-info" style="display:inline-box"><input class="box" type="text" name="movie_link[]" placeholder="Enter Your Movie Link" style="width:70%;"><a href="#">Remove Link</a></div>';
		$('.movie-link-wrapper').append(html);
	});

	$(document).on('click','.movie-link-info a',function(e){
		e.preventDefault();
		$(this).parent().remove();
	});

});
</script>
  	
</body>
</html>
