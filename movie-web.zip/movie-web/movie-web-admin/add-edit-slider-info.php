<?php include_once('connection.php'); 

if (isset($_POST['update_form'])) {

	$data['id_slider'] = $_POST['id_slider'];
	$data['slider_name'] = addslashes($_POST['slider_name']);
	$data['slider_link'] = addslashes($_POST['slider_link']);
	$data['slider_is_status'] = (isset($_POST['slider_is_status']) && $_POST['slider_is_status'] == 'on' ? '1' : '0');


	$slider_img = '';
	if (isset($_FILES['slider_img']['name']) && !empty($_FILES['slider_img']['name'])) {
		$image = $_FILES['slider_img'];
		$slider_img = $connection->insertSliderImage($image);
		if ($slider_img == false) {
			$select_movie_img = $connection->selectSliderImage($data['id_slider']);
		}
	}
	$data['slider_img'] = $slider_img;

	$return_data = $connection->updateMainSliderInformation($data);
	header("Location:slider-information.php");
}


if (isset($_POST['add_form'])) {	
	$data['slider_name'] = addslashes($_POST['slider_name']);
	$data['slider_link'] = addslashes($_POST['slider_link']);
	$data['slider_is_status'] = (isset($_POST['slider_is_status']) && $_POST['slider_is_status'] == 'on' ? '1' : '0');


	// $image = $_FILES['slider_img'];
	$file_name = '';
	if (isset($_FILES['slider_img']['name']) && !empty($_FILES['slider_img']['name'])) {
		$file = $_FILES['slider_img'];
		$file_name = $connection->insertSliderImage($file);
	}
	$data['slider_img'] = $file_name;

	// insert full Slider information
	$return_data = $connection->insertMainSliderInformation($data);
	header("Location:slider-information.php");
}



?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Slider Post Form</title>

<link href="css/post-style.css" rel="stylesheet" type="text/css"/>
</head>

<body>
<form method="post" action="add-edit-slider-info.php" enctype="multipart/form-data">
	<table border="0" cellpadding="20" cellspacing="20" class="post-box">
		<thead >
			<?php
			$title = ((isset($_GET['id']) && !empty($_GET['id'])) ? 'Slider Edit' : 'Slider Add'); ?>
			<label style="text-align: center;"><h1><?php echo $title; ?></h1></label>
		</thead>

		<?php 
		
		$data['id'] = (isset($_GET['id']) && !empty($_GET['id']) ? $_GET['id'] : '');

		$return_data = '';
		if ($data['id'] != '') {
			$return_data = $connection->selectFullSliderInformation($data); ?>
			<input type='hidden' name='id_slider' value='<?php echo $return_data['id_slider']; ?>'> <?php 
		} ?>

		<tbody>
			<tr>
				<td><label>Name :-</label></td>
				<td>
				<?php $tmp = (!empty($return_data) ? $return_data['slider_name'] : '');  ?>
					<input class="box" type="text" name="slider_name" id="#1" placeholder="Enter Your Slider Title" value="<?php echo $tmp; ?>">
				</td>
			</tr>

			<tr>
				<td><label>Link :-</label></td>
				<td>
				<?php $tmp = (!empty($return_data) ? $return_data['slider_link'] : '');  ?>
					<input class="box" type="text" name="slider_link" id="#1" placeholder="Enter Your Slider Link" value="<?php echo $tmp; ?>">
				</td>
			</tr>


			<tr>
				<td><label>Slider Image :- </label></td>
				<td>
					<input type="file" name="slider_img">
					<?php $tmp = (!empty($return_data) ? $return_data['slider_img'] : ''); 
					$html = '';
					if (!empty($tmp)) {
						$html .= '<img src=\''.BASE_CLIENT_URL.'images/slider-img/'.$tmp.'\' width=\'50%\'>';
					}
					echo $html; ?>
				</td>
			</tr>


			<tr>
				<td><label>Slider Status</label></td>
				<td>
					<?php $tmp = (!empty($return_data) ? $return_data['slider_is_status'] : ''); ?>
					<input type="checkbox" name="slider_is_status" <?php echo ($tmp == '1' ? 'checked=\'checked\'' : ''); ?>>
				</td>
			</tr>


			<tr>
				<td colspan="2">
					<input class="submit" type="submit" name="<?php echo (!empty($return_data) ? 'update_form' : 'add_form') ?>" value="Submit">
				</td>
			</tr>
		</tbody>
	</table>
</form>
  	
</body>
</html>
