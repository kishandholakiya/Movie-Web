<?php

include_once('connection.php');

$data['id'] = (!empty($_GET['id']) ? $_GET['id'] : '');
$data['name'] = (!empty($_GET['name']) ? $_GET['name'] : '');

$return = $connection->deleteMovieSliderImage($data);

$return_data = 'wrong';
if ($return == true && !empty($data['name'])) {
	$name = $_SERVER['CONTEXT_DOCUMENT_ROOT'].'/movie-web/images/movie-slider-img/'.$data['name'];
	if(file_exists($name)) {
		unlink($name);
		$return_data = 'right';

	}
}

echo $return_data;
