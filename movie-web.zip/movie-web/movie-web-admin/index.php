<?php include_once("connection.php"); 

$connection = new Connection();
$check_login = $connection->checkCookie();
if ($check_login) {
    header("Location:dashboard.php");
}


if (isset($_POST['login-info'])) {
    $data = array(); 
    $data['email'] = $_POST['email'];
    $data['password'] = $_POST['password'];
    $data['checkbox'] = (isset($_POST['checkbox']) ? $_POST['checkbox'] : '0');
 
    $data = json_encode($data);
    $return_data = $connection->checkAdminLoginInfo($data);

    $return_data = json_decode($return_data);

    // print_r($return_data);
    // exit;
    if ($return_data->success == '1') {
        header("Location:".BASE_URL."dashboard.php");
    } else {
        header("Location:".BASE_URL."index.php?error=".$return_data->message);
    }
} 

// if (isset($_COOKIE['wb-movie-admin-login']) && $_COOKIE['wb-movie-admin-login'] == 'true') {
//     header("Location:".BASE_URL."dashboard.php");
// }

// exit;        


// $connection->insertData();



 ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <title>Ela - Bootstrap Admin Dashboard Template</title>
    <!-- Bootstrap Core CSS -->
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:** -->
    <!--[if lt IE 9]>
    <script src="https:**oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https:**oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body class="fix-header fix-sidebar">
    <!-- Preloader - style you can find in spinners.css -->
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
			<circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>
    <!-- Main wrapper  -->
    <div id="main-wrapper">

        <div class="unix-login">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-lg-4">
                        <div class="login-content card">
                            <div class="login-form">
                                <h4>Login</h4>
                                <form action="<?php echo BASE_URL.'index.php'; ?>" method='post'>
                                    <?php 
                                    $msg = '';
                                    if (isset($_GET['error'])) {
                                        if ($_GET['error'] == 'admin_is_block') {
                                            $msg .= '<p>You are Block by Super Super.</p>';
                                        }

                                        if ($_GET['error'] == 'no_record_found') {
                                            $msg .= '<p>Please enter Valid User name And Password.</p>';
                                        }
                                    }
                                    echo $msg;
                                    ?>
                                    <div class="form-group">
                                        <label>Email address</label>
                                        <input type="email" name='email' class="form-control" placeholder="Email">
                                    </div>
                                    <div class="form-group">
                                        <label>Password</label>
                                        <input type="password" name="password" class="form-control" placeholder="Password">
                                    </div>
                                    <div class="checkbox">
                                        <label>
        										<input type="checkbox" name="checkbox" value='1'> Remember Me
        									</label>
                                            <!-- <label class="pull-right">
        										<a href="#">Forgotten Password?</a>
        									</label> -->

                                    </div>
                                    <button type="submit" name='login-info' class="btn btn-primary btn-flat m-b-30 m-t-30">Sign in</button>
                                    <!-- <div class="register-link m-t-15 text-center">
                                        <p>Don't have account ? <a href="#"> Sign Up Here</a></p>
                                    </div> -->
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- End Wrapper -->
    <!-- All Jquery -->
    <script src="js/lib/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Menu sidebar -->
    <script src="js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <!--Custom JavaScript -->
    <script src="js/scripts.js"></script>

</body>

</html>