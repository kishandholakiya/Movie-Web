<div class="left-sidebar">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <li class="nav-devider"></li>
                <li class="nav-label">Home</li>
                <li>
                    <a href="#" aria-expanded="false">
                        <i class="fa fa-tachometer"></i>
                        <span class="hide-menu">Dashboard</span>
                    </a>
                </li>
                
                <li> 
                    <a class="has-arrow" href="#" aria-expanded="false">
                        <i class="fa fa-wpforms"></i>
                        <span class="hide-menu">Movie Information</span>
                    </a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="movie-list.php">Movie List</a></li>
                    </ul>
                </li>

                <li>
                    <a class="has-arrow" href="#" aria-expanded="false">
                        <i class="fa fa-wpforms"></i>
                        <span class="hide-menu">Slider Information</span>
                    </a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="slider-information.php">Main Slider</a></li>
                        <li><a href="slider-information-2.php">Upcomming Movie Slider</a></li>
                    </ul>
                </li>

                <!-- <li>
                    <a href="">
                        <i class="fa fa-table"></i>
                        <span class="hide-menu"></span>
                    </a>
                </li> -->

                <li> <a class="has-arrow" href="customer-information.php" aria-expanded="false"><i class="fa fa-user-circle"></i><span class="hide-menu">Customer Messages</span></a>
                </li>
               
                
            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</div>