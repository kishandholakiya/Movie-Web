<?php include_once('connection.php'); ?>


<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width">
<meta name="robots" content="index|follow">
<meta name="description" content="freemovie4you.com is online free movies download website.this website provide a best quality movies. freemovie4you also provide a large collection of different movies like bollywood, hollywood, south and gujarati movies.You can free download any movies without login or registration.">
<meta name="keywords" content="freemovie4you, freemovies4you, free movies download, hd movies download, movie download site, bollywood movies download">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="googlebot" content="index, follow" />
<meta property="og:image" content="https://freemovie4you.com/movie-web/images/freemovie4you-poster.jpg" />
<meta property="og:description" content="Bollywood, Hollywood, South and Gujarati Full HD Free Movies Download Now" />
<meta property="og:url" content="https://www.freemovie4you.com" />
<title>Latest Movie</title>
<link href="bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
<link href="css/media-query.css" rel="stylesheet" type="text/css"/>
<link href="css/fontawesome-all.min.css" rel="stylesheet" type="text/css"/>
</head>

<body>

<?php include_once("header.php"); ?>

<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-lg-8 latest title-txt my-1">
				<div class="row">
					<div class="col-12 title-txt">
						<h3><a href="#">Pad Man Torrent 2018 Hindi Movie Poster</a></h3>
						<time><i class="far fa-clock mt-2"></i><span class="pld-10">May 25,2018</span></time>
						<hr/>
					</div>
					<div class="col-12 my-3">
						<div class="row">
							<div class="col-lg-5 col-md-6">
								<figure>
									<img src="images/Post-1.jpg" class="img-fluid" alt="Pad Man" title="Pad Man"/>
								</figure>
							</div>
							<div class="col-lg-7 col-md-6">
								<p>Quick Download Pad Man Torrent Movie 2018 In Your PC, Mobiles & Smart Phones Devices. Pad Man Full Movie Torrent Download With High Quality Here. Pad Man 2018 Is Related To Indian Biography Movies And Indian Drama Movies. We Have Also Wide Collection Of Latest Bollywood Movies In HD Result Bollywood Torrent Movies.   <a href="#">Read More.</a></p>
							</div>
						</div>
					</div>	
				</div>
				

			<?php include_once("right-panel.php"); ?>

		</div>
</div>

<?php include_once("footer.php"); ?>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" crossorigin="anonymous"></script>
<script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
</body>
</html>
