<?php 
include_once('connection.php');
$id = (isset($_GET['id']) && !empty($_GET['id']) ? $_GET['id'] : '');
if (empty($id)) {
	header("Location:index.php");
} ?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width">
<meta name="robots" content="index|follow">
<meta name="description" content="freemovie4you.com is online free movies download website.this website provide a best quality movies. freemovie4you also provide a large collection of different movies like bollywood, hollywood, south and gujarati movies.You can free download any movies without login or registration.">
<meta name="keywords" content="freemovie4you, freemovies4you, free movies download, hd movies download, movie download site, bollywood movies download">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="googlebot" content="index, follow" />
<meta property="og:image" content="https://www.fast2sms.com/og_image.jpg" />
<meta property="og:description" content="Bollywood, Hollywood, South and Gujarati Full HD Free Movies Download Now" />
<meta property="og:url" content="https://www.freemovie4you.com" />
<title>Free Latest Movies Download Now - HD Quality Movies Avaliable</title>
<link href="bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
<link href="css/media-query.css" rel="stylesheet" type="text/css"/>
<link href="css/fontawesome-all.min.css" rel="stylesheet" type="text/css"/>
</head>

<body class="bg-main">






<div class="container-fluid">
		<div class="row">
			<h3 class="download-now-h3">Download Now</h3>
		</div>
		<div class="row">
			<div class="col-sm-12 col-lg-3">

			</div>
			<div class="col-sm-12 col-lg-6">
				<?php 
					$ids = str_split($id);
					$count = count($ids);
					$i = 0;
					$new_id = '';
					foreach($ids as $id) {
						if ($i>= 5) {
							$new_id .= $id;
						}
						$i++;
					}

					$data['id_movie_info'] = (string)$new_id;
					$return_data = $connection->selectMovieLink($data);
					$html = '';
					if ($return_data) {
						$ans = mysqli_fetch_assoc($return_data);
						$html .= '<div class="col-lg-12 col-sm-12 col-12 text-center p-4 link-box text-light">
							<h3><b>'.$ans['movie_name'].'</b></h3>';
						$links = explode('#$%^&*()', $ans['movie_link']);
						foreach($links as $link){
							$name = explode('/',$link);
							$c = count($name);

							$html .= '<a href="'.$link.'" class="open-new-tab" data-link-show="'.$link.'">'.$link.'</a>
						<hr/>';	
						}
						$html .= '</div>';

					}
					echo $html;

					?>
			</div>
			<div class="col-sm-12 col-lg-3">

			</div>
		</div>
		
</div>
<div class="container-fluid">
		<div class="col-lg-12 add-area">
			
		</div>
</div>





<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" crossorigin="anonymous"></script>
<script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
<script>
$(document).ready(function(){
	$('.open-new-tab').click(function(e){
		e.preventDefault();
		console.log('right');
		var data = $(this).attr('data-link-show');
		window.open(data);
	});
});
</script>
</body>
</html>
