<?php include_once('connection.php'); ?>
<?php if (!isset($_GET['page']) || empty($_GET['page']) || $_GET['page'] == 'index'): ?>
	<?php if (!isset($_GET['search']) || empty($_GET['page'])): ?>
	<div class='container-fluid'>
		<div class='row'>
			<div class='col-lg-12 col-sm-12 col-12'>
				<div class='main-slider-info owl-carousel owl-theme my-3'>
					<?php 
					$data = '';
					$result = $connection->selectSliderInformation($data); 
					while($ans = mysqli_fetch_assoc($result)) { 
						if ($ans['slider_is_status'] == '1') { ?>
							<div class='item'>
								<figure>
									<a href='<?php echo $ans['slider_link']; ?>'>
										<img src="images/slider-img/<?php echo $ans['slider_img']; ?>" class='img-fluid' alt='1' title="<?php echo $ans['slider_name']; ?>"/>
									</a>
								</figure>
							</div> <?php 
						} 
					} ?>
				</div>
			</div>
		</div>
	</div>
	<?php endif; ?>
<?php endif; ?>