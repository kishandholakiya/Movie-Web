<?php include_once('connection.php'); 
$data = array();

// echo "asdasd";
// print_r($_GET['page']);

$data['id_movie_type'] = (isset($_GET['page']) && !empty($_GET['page'])?$_GET['page']:'1');

if (isset($_GET['search']) && !empty($_GET['pagin'])) {
	$data['search'] = $_GET['search'];
	$data['id_movie_type'] = 'index';
}

$data['start'] = (isset($_GET['pagin']) && !empty($_GET['pagin']) ? $_GET['pagin'] : '1');

$data['search'] = (isset($_GET['search']) && !empty($_GET['search']) ? $_GET['search'] : '');


$data['movie'] = (isset($_GET['movie']) && !empty($_GET['movie']) ? $_GET['movie'] : '');
if (isset($_GET['movie']) && !empty($_GET['movie'])) {
	$return = $connection->selectFullMovieList($data);
} else {
	$return = $connection->selectMovieList($data);
}

$html = '';
if (isset($_GET['movie'])) {
	$html = '';
	$ans = mysqli_fetch_assoc($return);
	include_once('movie-info.php');

} else {
	if (isset($data['search']) && !empty($data['search'])) {
		$html .= '<script type="text/javascript">$(document).find(\'.slider-info\').html(\'\');</script>';
	}

	if ($data['id_movie_type'] != '5' || (isset($data['search']) && !empty($data['search']))) {
		$i = 1;
		// if (mysqli_count_rows($retur))
		$record_count = mysqli_num_rows($return);
		if ($record_count <= 0) {
			$html .= '<div class=\'no-data\'>
				This Movie Are Not Found
			</div>';
		} else {
			while($ans = mysqli_fetch_assoc($return)) {
				if ($ans['movie_is_status'] == '1') {
					$timestamp = strtotime($ans['movie_release_date']); 
					$new_date = date('M d,Y', $timestamp);

					$html .= '<div class="col-lg-4 col-sm-6 mani-box title-txt">
							<a href="'.BASE_URL.'?movie='.$ans['id_movie_info'].'" class="wb-movie-info-name" data-movie-id="'.$ans['id_movie_info'].'">
							<div class="col-12 p-0">
								<img src="images/movie-img/'.$ans['movie_info_img'].'" class="img-fluid" alt="'.$ans['movie_name'].'" title="'.$ans['movie_name'].'"/>
							</div>
							<h5 class="m-0 py-2">'.$ans['movie_name'].'</h5>
							<time><i class="far fa-clock mt-2"></i><span class="pl-2">'.$new_date.'</span></time>
						</a>	
					</div>';
					$i++;
				}
			}
		}
	} else {
		$record_count = mysqli_num_rows($return);
		if ($record_count <= 0) {
			$html .= '<div class=\'no-data\'>
				No Data Found
			</div>';
		} else {
			while($ans = mysqli_fetch_assoc($return)) {
				if ($ans['movie_is_status'] == '1') {
					$timestamp = strtotime($ans['movie_release_date']); 
					$new_date = date('M d,Y', $timestamp);
					$html .= '<div class="col-12">
								<h3><a href="#" class="wb-movie-info-name" data-movie-id="'.$ans['id_movie_info'].'">'.$ans['movie_name'].'</a></h3>
								<time><i class="far fa-clock mt-2"></i><span class="pl-2">'.$new_date.'</span></time>
								<hr/>
							</div>
							<div class="col-12 my-3">
								<div class="row">
									<div class="col-lg-5 col-md-6">
										<figure>
											<img src="images/movie-img/'.$ans['movie_info_img'].'" class="img-fluid" alt="'.$ans['movie_name'].'" title="'.$ans['movie_name'].'"/>
										</figure>
									</div>
									<div class="col-lg-7 col-md-6">
										<p>'.$ans['movie_description'].'<a href="#" class="wb-movie-info-name" data-movie-id="'.$ans['id_movie_info'].'">Read More.</a></p>
									</div>
								</div>
							</div>';
				}
			}
		}
	}
}


echo $html; ?>
