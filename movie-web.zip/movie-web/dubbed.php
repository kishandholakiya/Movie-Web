<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width">
<meta name="robots" content="index|follow">
<meta name="description" content="freemovie4you.com is online free movies download website.this website provide a best quality movies. freemovie4you also provide a large collection of different movies like bollywood, hollywood, south and gujarati movies.You can free download any movies without login or registration.">
<meta name="keywords" content="freemovie4you, freemovies4you, free movies download, hd movies download, movie download site, bollywood movies download">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="googlebot" content="index, follow" />
<meta property="og:image" content="https://freemovie4you.com/movie-web/images/freemovie4you-poster.jpg" />
<meta property="og:description" content="Bollywood, Hollywood, South and Gujarati Full HD Free Movies Download Now" />
<meta property="og:url" content="https://www.freemovie4you.com" />
<title>Dubbed</title>
<link href="bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
<link href="css/media-query.css" rel="stylesheet" type="text/css"/>
<link href="css/fontawesome-all.min.css" rel="stylesheet" type="text/css"/>
</head>

<body>

<?php include_once("header.php"); ?>

<div class="container-fluid">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-lg-8">
				<div class="row">
					<div class="col-lg-4 col-sm-6 mani-box title-txt">
						<div class="col-12 p-0">
							<img src="images/Post-1.jpg" class="img-fluid" alt="Deadpool 2" title="Deadpool 2"/>
						</div>
						<h5 class="m-0 py-2"><a href="#">Deadpool 2 In Hindi Dubbed Torrent Full Movie Download HD 2018</a></h5>
						<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
					</div>
					<div class="col-lg-4 col-sm-6 mani-box title-txt">
						<div class="col-12 p-0">
							<img src="images/Post-1.jpg" class="img-fluid" alt="Deadpool 2" title="Deadpool 2"/>
						</div>
						<h5 class="m-0 py-2"><a href="#">Deadpool 2 In Hindi Dubbed Torrent Full Movie Download HD 2018</a></h5>
						<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
					</div>
					<div class="col-lg-4 col-sm-6 mani-box title-txt">
						<div class="col-12 p-0">
							<img src="images/Post-1.jpg" class="img-fluid" alt="Deadpool 2" title="Deadpool 2"/>
						</div>
						<h5 class="m-0 py-2"><a href="#">Deadpool 2 In Hindi Dubbed Torrent Full Movie Download HD 2018</a></h5>
						<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
					</div>
					<div class="col-lg-4 col-sm-6 mani-box title-txt">
						<div class="col-12 p-0">
							<img src="images/Post-1.jpg" class="img-fluid" alt="Deadpool 2" title="Deadpool 2"/>
						</div>
						<h5 class="m-0 py-2"><a href="#">Deadpool 2 In Hindi Dubbed Torrent Full Movie Download HD 2018</a></h5>
						<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
					</div>
					<div class="col-lg-4 col-sm-6 mani-box title-txt">
						<div class="col-12 p-0">
							<img src="images/Post-1.jpg" class="img-fluid" alt="Deadpool 2" title="Deadpool 2"/>
						</div>
						<h5 class="m-0 py-2"><a href="#">Deadpool 2 In Hindi Dubbed Torrent Full Movie Download HD 2018</a></h5>
						<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
					</div>
					<div class="col-lg-4 col-sm-6 mani-box title-txt">
						<div class="col-12 p-0">
							<img src="images/Post-1.jpg" class="img-fluid" alt="Deadpool 2" title="Deadpool 2"/>
						</div>
						<h5 class="m-0 py-2"><a href="#">Deadpool 2 In Hindi Dubbed Torrent Full Movie Download HD 2018</a></h5>
						<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
					</div>
					<div class="col-lg-4 col-sm-6 mani-box title-txt">
						<div class="col-12 p-0">
							<img src="images/Post-1.jpg" class="img-fluid" alt="Deadpool 2" title="Deadpool 2"/>
						</div>
						<h5 class="m-0 py-2"><a href="#">Deadpool 2 In Hindi Dubbed Torrent Full Movie Download HD 2018</a></h5>
						<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
					</div>
					<div class="col-lg-4 col-sm-6 mani-box title-txt">
						<div class="col-12 p-0">
							<img src="images/Post-1.jpg" class="img-fluid" alt="Deadpool 2" title="Deadpool 2"/>
						</div>
						<h5 class="m-0 py-2"><a href="#">Deadpool 2 In Hindi Dubbed Torrent Full Movie Download HD 2018</a></h5>
						<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
					</div>
					<div class="col-lg-4 col-sm-6 mani-box title-txt">
						<div class="col-12 p-0">
							<img src="images/Post-1.jpg" class="img-fluid" alt="Deadpool 2" title="Deadpool 2"/>
						</div>
						<h5 class="m-0 py-2"><a href="#">Deadpool 2 In Hindi Dubbed Torrent Full Movie Download HD 2018</a></h5>
						<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
					</div>
					<div class="col-lg-4 col-sm-6 mani-box title-txt">
						<div class="col-12 p-0">
							<img src="images/Post-1.jpg" class="img-fluid" alt="Deadpool 2" title="Deadpool 2"/>
						</div>
						<h5 class="m-0 py-2"><a href="#">Deadpool 2 In Hindi Dubbed Torrent Full Movie Download HD 2018</a></h5>
						<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
					</div>
					<div class="col-lg-4 col-sm-6 mani-box title-txt">
						<div class="col-12 p-0">
							<img src="images/Post-1.jpg" class="img-fluid" alt="Deadpool 2" title="Deadpool 2"/>
						</div>
						<h5 class="m-0 py-2"><a href="#">Deadpool 2 In Hindi Dubbed Torrent Full Movie Download HD 2018</a></h5>
						<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
					</div>
					<div class="col-lg-4 col-sm-6 mani-box title-txt">
						<div class="col-12 p-0">
							<img src="images/Post-1.jpg" class="img-fluid" alt="Deadpool 2" title="Deadpool 2"/>
						</div>
						<h5 class="m-0 py-2"><a href="#">Deadpool 2 In Hindi Dubbed Torrent Full Movie Download HD 2018</a></h5>
						<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
					</div>
					<div class="col-lg-4 col-sm-6 mani-box title-txt">
						<div class="col-12 p-0">
							<img src="images/Post-1.jpg" class="img-fluid" alt="Deadpool 2" title="Deadpool 2"/>
						</div>
						<h5 class="m-0 py-2"><a href="#">Deadpool 2 In Hindi Dubbed Torrent Full Movie Download HD 2018</a></h5>
						<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
					</div>
					<div class="col-lg-4 col-sm-6 mani-box title-txt">
						<div class="col-12 p-0">
							<img src="images/Post-1.jpg" class="img-fluid" alt="Deadpool 2" title="Deadpool 2"/>
						</div>
						<h5 class="m-0 py-2"><a href="#">Deadpool 2 In Hindi Dubbed Torrent Full Movie Download HD 2018</a></h5>
						<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
					</div>
					<div class="col-lg-4 col-sm-6 mani-box title-txt">
						<div class="col-12 p-0">
							<img src="images/Post-1.jpg" class="img-fluid" alt="Deadpool 2" title="Deadpool 2"/>
						</div>
						<h5 class="m-0 py-2"><a href="#">Deadpool 2 In Hindi Dubbed Torrent Full Movie Download HD 2018</a></h5>
						<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
					</div>
				</div>
			</div> 
			
			<?php include_once("right-panel.php"); ?>

		</div>
	</div>
</div>

<?php include_once("footer.php"); ?>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" crossorigin="anonymous"></script>
<script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
</body>
</html>
