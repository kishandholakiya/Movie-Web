<?php

$return = '';
if (isset($_GET['email-id']) && !empty($_GET['email-id']))
{
	include_once('connection.php');
	$email_id = $_GET['email-id'];
	$ans = $connection->checkEmailIdForSubscribe($email_id);
	if ($ans) {
		$return = $connection->insertEmailSubscribe($email_id);
		if ($return == true) {
			$return = 'confirm';
		} else {
			$return = 'connection_error';
		}
	} else {
		$return = 'email_already_register';
	}
} else {
	$return = 'connection_error';
}

echo $return;

