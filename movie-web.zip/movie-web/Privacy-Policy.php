<?php include_once('connection.php'); ?>
<!doctype html>
<html lang="en">
<head>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-120213160-4"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-120213160-4');
</script>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width">
<meta name="robots" content="index|follow">
<meta name="description" content="freemovie4you.com is online free movies download website.this website provide a best quality movies. freemovie4you also provide a large collection of different movies like bollywood, hollywood, south and gujarati movies.You can free download any movies without login or registration.">
<meta name="keywords" content="freemovie4you, freemovies4you, free movies download, hd movies download, movie download site, bollywood movies download">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="googlebot" content="index, follow" />
<meta property="og:image" content="https://freemovie4you.com/movie-web/images/freemovie4you-poster.jpg" />
<meta property="og:description" content="Bollywood, Hollywood, South and Gujarati Full HD Free Movies Download Now" />
<meta property="og:url" content="https://www.freemovie4you.com" />
<title>Privacy &amp; Policy</title>
        <link href="images/popcorn.png" rel="icon">
	<link href="bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	<link href="css/style.css" rel="stylesheet" type="text/css"/>
	<link href="css/media-query.css" rel="stylesheet" type="text/css"/>
	<link href="css/fontawesome-all.min.css" rel="stylesheet" type="text/css"/>
</head>
<body>

<?php include_once("header_show.php"); ?>

	
    <div class="container-fluid">
    	<div class="container">
        	<div class="row pt-3 pb-2">
            	<div class="col-lg-12">
                	<article class="policy-set">
                    	<h1 class="policy-change">Our Privacy And Policy</h1>
                    	<p>This privacy policy has been compiled to better serve those who are concerned with how their 'Personally Identifiable Information' (PII) is being used online. PII, as described in US privacy law and information security, is information that can be used on its own or with other information to identify, contact, or locate a single person, or to identify an individual in context. Please read our privacy policy carefully to get a clear understanding of how we collect, use, protect or otherwise handle your Personally Identifiable Information in accordance with our website.</p>
                        <h6>What personal information do we collect from the people that visit our blog, website or app?</h6>
                    	<p>When ordering or registering on our site, as appropriate, you may be asked to enter your name, email address, mailing address, social security number or other details to help you with your experience.</p>    
                        <h6>When do we collect information?</h6>
                        <p>We collect information from you when you register on our site, subscribe to a newsletter, fill out a form or enter information on our site.</p>
                        <h6>How do we use your information?</h6>
                        <p>We may use the information we collect from you when you register, make a purchase, sign up for our newsletter, respond to a survey or marketing communication, surf the website, or use certain other site features in the following ways:
                        	<ul>
                            	<li>1. To improve our website in order to better serve you.</li>
                                <li>2. To allow us to better service you in responding to your customer service requests.</li>
                                <li>3. To ask for ratings and reviews of services or products</li>
                            </ul>
                        </p>
                        <h6>How do we protect your information?</h6>
                        <p>We do not use vulnerability scanning and/or scanning to PCI standards.We only provide articles and information. We never ask for credit card numbers.We use regular Malware Scanning.</p>
                        <p>Your personal information is contained behind secured networks and is only accessible by a limited number of persons who have special access rights to such systems, and are required to keep the information confidential. In addition, all sensitive/credit information you supply is encrypted via Secure Socket Layer (SSL) technology.We implement a variety of security measures when a user enters, submits, or accesses their information to maintain the safety of your personal information.All transactions are processed through a gateway provider and are not stored or processed on our servers.</p>
						<h6>Do we use 'cookies'?</h6>
                        <p>We do not use cookies for tracking purposes.You can choose to have your computer warn you each time a cookie is being sent, or you can choose to turn off all cookies. You do this through your browser settings. Since browser is a little different, look at your browser's Help Menu to learn the correct way to modify your cookies.If you turn cookies off.</p>
                        <h6>Third-party disclosure</h6>
                        <p>We do not sell, trade, or otherwise transfer to outside parties your Personally Identifiable Information unless we provide users with advance notice. This does not include website hosting partners and other parties who assist us in operating our website, conducting our business, or serving our users, so long as those parties agree to keep this information confidential. We may also release information when it's release is appropriate to comply with the law, enforce our site policies, or protect ours or others' rights, property or safety.However, non-personally identifiable visitor information may be provided to other parties for marketing, advertising, or other uses.</p>
                        <h6>Third-party links</h6>
                        <p>Occasionally, at our discretion, we may include or offer third-party products or services on our website. These third-party sites have separate and independent privacy policies. We therefore have no responsibility or liability for the content and activities of these linked sites. Nonetheless, we seek to protect the integrity of our site and welcome any feedback about these sites.</p>
                        <h6>Google Advertisement</h6>
                        <p>Google's advertising requirements can be summed up by Google's Advertising Principles. They are put in place to provide a positive experience for users. <a href="https://support.google.com/adwordspolicy/answer/1316548?hl=en" style="font-size: 9px !important;">https://support.google.com/adwordspolicy/answer/1316548?hl=en</a> </p>
                        <p>We use Google AdSense Advertising on our website.</p>
                        <p>Google, as a third-party vendor, uses cookies to serve ads on our site. Google's use of the DART cookie enables it to serve ads to our users based on previous visits to our site and other sites on the Internet. Users may opt-out of the use of the DART cookie by visiting the Google Ad and Content Network privacy policy.</p>
                        <h6>We have implemented the following:</h6>
                        <p>
                        	<ul>
                            	<li>1. Remarketing with Google AdSense</li>
                                <li>2. Google Display Network Impression Reporting</li>
                                <li>3. Demographics and Interests Reporting</li>
                                <li>4. DoubleClick Platform Integration</li>
                            </ul>
                        </p>
                        <p>We, along with third-party vendors such as Google use first-party cookies (such as the Google Analytics cookies) and third-party cookies (such as the DoubleClick cookie) or other third-party identifiers together to compile data regarding user interactions with ad impressions and other ad service functions as they relate to our website.</p>
                        <h6>Opting out:</h6>
                        <p>Users can set preferences for how Google advertises to you using the Google Ad Settings page. Alternatively, you can opt out by visiting the Network Advertising Initiative Opt Out page or by using the Google Analytics Opt Out Browser add on.</p>
                        <h6>California Online Privacy Protection Act</h6>
                        <p>CalOPPA is the first state law in the nation to require commercial websites and online services to post a privacy policy. The law's reach stretches well beyond California to require any person or company in the United States (and conceivably the world) that operates websites collecting Personally Identifiable Information from California consumers to post a conspicuous privacy policy on its website stating exactly the information being collected and those individuals or companies with whom it is being shared. - See more at: http://consumercal.org/california-online-privacy-protection-act-caloppa/#sthash.0FdRbT51.dpuf</p>
                        <h6>According to CalOPPA, we agree to the following:</h6>
                        <p>Users can visit our site anonymously.Once this privacy policy is created, we will add a link to it on our home page or as a minimum, on the first significant page after entering our website.Our Privacy Policy link includes the word 'Privacy' and can easily be found on the page specified above.</p>
						<p>You will be notified of any Privacy Policy changes: Via Email</p>
						<p>Can change your personal information: By emailing us</p>
                        <h6>How does our site handle Do Not Track signals?</h6>
                        <p>We honor Do Not Track signals and Do Not Track, plant cookies, or use advertising when a Do Not Track (DNT) browser mechanism is in place. </p>
                        <h6>Does our site allow third-party behavioral tracking?</h6>
                        <p>It's also important to note that we do not allow third-party behavioral tracking</p>
                        <h6>COPPA (Children Online Privacy Protection Act)</h6>
                        <p>When it comes to the collection of personal information from children under the age of 13 years old, the Children's Online Privacy Protection Act (COPPA) puts parents in control. The Federal Trade Commission, United States' consumer protection agency, enforces the COPPA Rule, which spells out what operators of websites and online services must do to protect children's privacy and safety online.We do not collect information from children under 13.</p>
                        <h6>Fair Information Practices</h6>
                        <p>The Fair Information Practices Principles form the backbone of privacy law in the United States and the concepts they include have played a significant role in the development of data protection laws around the globe. Understanding the Fair Information Practice Principles and how they should be implemented is critical to comply with the various privacy laws that protect personal information.</p>
                        <h6>In order to be in line with Fair Information Practices we will take the following responsive action, should a data breach occur:</h6>
                        <p>
                        	<ul>
                            	<li>We will notify you via email : Within 7 business days</li>
                                <li>We will notify you via phone call : Within 7 business days</li>
                                <li>We will notify you via letter : Within 7 business days</li>
                            </ul>
                        </p>
                        <p>We also agree to the Individual Redress Principle which requires that individuals have the right to legally pursue enforceable rights against data collectors and processors who fail to adhere to the law. This principle requires not only that individuals have enforceable rights against data users, but also that individuals have recourse to courts or government agencies to investigate and/or prosecute non-compliance by data processors.</p>
                        <h6>CAN SPAM Act</h6>
                        <p>The CAN-SPAM Act is a law that sets the rules for commercial email, establishes requirements for commercial messages, gives recipients the right to have emails stopped from being sent to them, and spells out tough penalties for violations.</p>
                        <h6>We collect your email address in order to:</h6>
                        <p>
                        	<ul>
                            	<li>1. Send information, respond to inquiries, and/or other requests or questions</li>
                                <li>2. Process orders and to send information and updates pertaining to orders.</li>
                                <li>3. Send you additional information related to your product and/or service</li>
                                <li>4. Market to our mailing list or continue to send emails to our clients after the original transaction has occurred.</li>
                            </ul>
                        </p>
                        <h6>To be in accordance with CANSPAM, we agree to the following:</h6>
                        <p>
                        	<ul>
                            	<li>1. Not use false or misleading subjects or email addresses.</li>
                                <li>2. Identify the message as an advertisement in some reasonable way.</li>
                                <li>3. Include the physical address of our business or site headquarters.</li>
                                <li>4. Monitor third-party email marketing services for compliance, if one is used.</li>
                                <li>5. Honor opt-out/unsubscribe requests quickly.</li>
                            </ul>
                        </p>
                    </article>
                </div>
            </div>
        </div>
    </div>
    
<?php include_once("footer.php"); ?>

	
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" crossorigin="anonymous"></script>
	<script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
<script>
    
$(document).on('click','.subscribe-input',function(){
    var emailaddress = $('.input-set-sub').val();
    if( validateEmail(emailaddress)) { 
        $.ajax({
        type: 'GET',
        url: 'insert-email.php?email-id='+emailaddress,
        cache: false,
        success: function(data)
        {
            if (data == 'confirm') {
                alert('Your Email is Subscribe.');
                $('.input-set-sub').val('');
            } else if(data =='email_already_register') {
                alert('Your Email is already Register.');
            } else {
                alert('Connection Error Accour.');
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
        }
    });
    } else {
        alert('Please Enter Valid Email Address.');
    }
});

function validateEmail($email) {
  var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
  return emailReg.test( $email );
}
</script>
	
</body>
</html>
