<div class="container-fluid header-info">

		<div class="col-sm-12 col-lg-3 text-center">
			<figure>
				<a href="index.php">
				<img src="images/Freeemovies4you-logo.png" alt="Logo" title="logo" class="img-fluid d-inline-block">
				</a>
			</figure>
		</div>
		<div class="col-sm-12 col-lg-9">
			<div class="custome-advertisement">
				
			</div>
		</div>
	</div>

	<nav class="navbar navbar-expand-lg navbar-light bg-hd br-bottom text-center">
  			<a class="navbar-brand" href="#">Navbar</a>
  			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    		<span class="navbar-toggler-icon"></span>
  			</button>

  			<div class="collapse navbar-collapse" id="navbarSupportedContent">
    		<ul class="navbar-nav mr-auto">
      			<li class="nav-item">
        			<a class="nav-link" href="index.php?page=index&pagin=1" data-id="index">Home</a>
      			</li>

      				      			<li class="nav-item">
	        			<a class="nav-link" href="index.php?page=1&pagin=1" data-id="1">Bollywood</a>
	      			</li> 	      			<li class="nav-item">
	        			<a class="nav-link" href="index.php?page=2&pagin=1" data-id="2">Hollywood</a>
	      			</li> 	      			<li class="nav-item">
	        			<a class="nav-link" href="index.php?page=3&pagin=1" data-id="3">South Indian</a>
	      			</li> 	      			<li class="nav-item">
	        			<a class="nav-link" href="index.php?page=4&pagin=1" data-id="4">Gujrati</a>
	      			</li> 	      			<li class="nav-item">
	        			<a class="nav-link" href="index.php?page=5&pagin=1" data-id="5">Latest</a>
	      			</li>     		</ul>
    		<!-- <div class="form-inline my-2 my-lg-0" action="#">
      			<input class="form-control mr-sm-2" type="search" placeholder="Search" id="movie-search" aria-label="Search">
      			<button class="btn btn-outline-light my-2 my-sm-0" type="button" id="movie-search-submit">Search</button>
    		</div> -->
  			</div>
		</nav>


<style type="text/css">
	.nav-item a{
		padding: 20px 22px !important;
		color: black !important;
		font-weight: 700;
		text-shadow: 0px 0px 3px black;
		text-transform: uppercase;
		color: white !important;
		transition: all 0.5s;
	}
	.nav-item a:hover{
		background-color: rgba(0,0,0,0.4);
		color: white !important;
		text-shadow: 0px 0px 3px black;
		box-shadow: 0px 0px 4px 2px #AB0025;
	}
	.nav-item a:focus{
		background-color: rgba(0,0,0,0.6);
		color: white !important;
		text-shadow: 0px 0px 3px black;
	}
	.br-bottom{
		border-bottom: 4px solid #AB0025;
	}
	.navbar-brand{
		display: none !important;
	}
	@media (max-width: 991.98px){
		.navbar-brand{
			display: block !important;
		}
	}
	.custome-advertisement{
		max-width: 100%;
		height: auto;
		overflow: hidden !important;
	}
	.bg-hd{
		background-color: #FF004F;
	}
	nav .line {
	  height: 3px;
	  position: absolute;
	  bottom: 0;
	  margin: 10px 0 0 0;
	  background: #FFFFFF;
	}
	nav ul {
	  padding: 0;
	  margin: 0;
	  list-style: none;
	  display: flex;
	}
	nav ul li:hover {
	  opacity: 0.7;
	}
	nav ul li.active {
	  opacity: 1;
	}
</style>


<script type="text/javascript">
var nav = $('nav');
var line = $('<div />').addClass('line');

line.appendTo(nav);

var active = nav.find('.active');
var pos = 0;
var wid = 0;

if(active.length) {
  pos = active.position().left;
  wid = active.width();
  line.css({
    left: pos,
    width: wid
  });
}

nav.find('ul li a').click(function(e) {
  e.preventDefault();
  if(!$(this).parent().hasClass('active') && !nav.hasClass('animate')) {
    
    nav.addClass('animate');

    var _this = $(this);

    nav.find('ul li').removeClass('active');

    var position = _this.parent().position();
    var width = _this.parent().width();

    if(position.left >= pos) {
      line.animate({
        width: ((position.left - pos) + width)
      }, 300, function() {
        line.animate({
          width: width,
          left: position.left
        }, 150, function() {
          nav.removeClass('animate');
        });
        _this.parent().addClass('active');
      });
    } else {
      line.animate({
        left: position.left,
        width: ((pos - position.left) + wid)
      }, 300, function() {
        line.animate({
          width: width
        }, 150, function() {
          nav.removeClass('animate');
        });
        _this.parent().addClass('active');
      });
    }

    pos = position.left;
    wid = width;
  }
});
</script>