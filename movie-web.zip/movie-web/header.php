	<div class="container-fluid header-info">
		<div class="row">
		<div class="col-lg-3 col-sm-12 text-center">
			<figure>
				<a href="<?php echo BASE_URL; ?>">
					<img src="images/Freeemovies4you-logo.png" alt="Logo" title="logo" class="img-fluid d-inline-block">
				</a>
			</figure>
		</div>
		<div class="col-lg-9 col-sm-12 align-self-center">
			<div class="dflax">
			<figure>
				<div class="a2a_kit a2a_default_style">
					<a class="a2a_button_facebook"></a>
					<a class="a2a_button_twitter"></a>
					<!-- <a class="a2a_button_google_plus"></a> -->
					<!-- <a class="a2a_button_email"></a> -->
					<!-- <a class="a2a_button_pinterest"></a> -->
					<a class="a2a_button_linkedin"></a>
					<!-- <a class="a2a_button_tumblr"></a> -->
					<!-- <a class="a2a_button_google_gmail"></a> -->
					<a class="a2a_button_reddit"></a>
					<a class="a2a_button_whatsapp"></a>
					<!-- <a class="a2a_button_mix"></a> -->
					<!-- <a class="a2a_button_amazon_wish_list"></a> -->
					<!-- <a class="a2a_button_balatarin"></a> -->
					<!-- <a class="a2a_button_bitty_browser"></a> -->
					<!-- <a class="a2a_button_blogger"></a> -->
					<!-- <a class="a2a_button_bibsonomy"></a> -->
					<!-- <a class="a2a_button_aol_mail"></a> -->
					<!-- <a class="a2a_button_stumbleupon"></a> -->
					<!-- <a class="a2a_button_wordpress"></a> -->
					<!-- <a class="a2a_button_blinklist"></a> -->
					<!-- <a class="a2a_button_blogmarks"></a> -->
					<!-- <a class="a2a_button_box_net"></a> -->
					<!-- <a class="a2a_button_care2_news"></a> -->
					<!-- <a class="a2a_button_copy_link"></a> -->
					<!-- <a class="a2a_button_douban"></a> -->
					<!-- <a class="a2a_button_digg"></a> -->
					<!-- <a class="a2a_button_diary_ru"></a> -->
					<!-- <a class="a2a_button_draugiem"></a> -->
					<!-- <a class="a2a_button_diigo"></a> -->
					<!-- <a class="a2a_button_diaspora"></a> -->
					<!-- <a class="a2a_button_design_float"></a> -->
					<!-- <a class="a2a_button_citeulike"></a> -->
					<!-- <a class="a2a_button_buffer"></a> -->
					<!-- <a class="a2a_button_bookmarks_fr"></a> -->
					<!-- <a class="a2a_button_evernote"></a> -->
					<!-- <a class="a2a_button_fark"></a> -->
					<!-- <a class="a2a_button_dzone"></a> -->
					<a class="a2a_button_facebook_messenger"></a>
					<!-- <a class="a2a_button_flipboard"></a> -->
					<!-- <a class="a2a_button_google_bookmarks"></a> -->
					<!-- <a class="a2a_button_hacker_news"></a> -->
					<!-- <a class="a2a_button_houzz"></a> -->
					<!-- <a class="a2a_button_kakao"></a> -->
					<!-- <a class="a2a_button_kindle_it"></a> -->
					<!-- <a class="a2a_button_known"></a> -->
					<!-- <a class="a2a_button_kik"></a> -->
					<!-- <a class="a2a_button_instapaper"></a> -->
					<!-- <a class="a2a_button_hatena"></a> -->
					<!-- <a class="a2a_button_google_classroom"></a> -->
					<!-- <a class="a2a_button_folkd"></a> -->
					<!-- <a class="a2a_button_livejournal"></a> -->
					<a class="a2a_button_line"></a>
					<!-- <a class="a2a_button_mendeley"></a> -->
					<!-- <a class="a2a_button_mail_ru"></a> -->
					<!-- <a class="a2a_button_netvouz"></a> -->
					<!-- <a class="a2a_button_outlook_com"></a> -->
					<!-- <a class="a2a_button_pinboard"></a> -->
					<!-- <a class="a2a_button_pocket"></a> -->
					<!-- <a class="a2a_button_printfriendly"></a> -->
					<!-- <a class="a2a_button_mixi"></a> -->
					<!-- <a class="a2a_button_mastodon"></a> -->
					<!-- <a class="a2a_button_myspace"></a> -->
					<!-- <a class="a2a_button_meneame"></a> -->
					<!-- <a class="a2a_button_odnoklassniki"></a> -->
					<!-- <a class="a2a_button_plurk"></a> -->
					<!-- <a class="a2a_button_papaly"></a> -->
					<!-- <a class="a2a_button_print"></a> -->
					<!-- <a class="a2a_button_protopage_bookmarks"></a> -->
					<!-- <a class="a2a_button_qzone"></a> -->
					<!-- <a class="a2a_button_pusha"></a> -->
					<a class="a2a_button_rediff"></a>
					<!-- <a class="a2a_button_renren"></a> -->
					<!-- <a class="a2a_button_sitejot"></a> -->
					<!-- <a class="a2a_button_stocktwits"></a> -->
					<!-- <a class="a2a_button_slashdot"></a> -->
					<!-- <a class="a2a_button_svejo"></a> -->
					<a class="a2a_button_sms"></a>
					<!-- <a class="a2a_button_skype"></a> -->
					<!-- <a class="a2a_button_sina_weibo"></a> -->
					<!-- <a class="a2a_button_refind"></a> -->
					<!-- <a class="a2a_button_trello"></a> -->
					<a class="a2a_button_telegram"></a>
					<!-- <a class="a2a_button_symbaloo_bookmarks"></a> -->
					<!-- <a class="a2a_button_threema"></a> -->
					<!-- <a class="a2a_button_tuenti"></a> -->
					<!-- <a class="a2a_button_typepad_post"></a> -->
					<!-- <a class="a2a_button_viber"></a> -->
					<!-- <a class="a2a_button_vk"></a> -->
					<!-- <a class="a2a_button_viadeo"></a> -->
					<!-- <a class="a2a_button_twiddla"></a> -->
					<a class="a2a_button_wechat"></a>
					<!-- <a class="a2a_button_xing"></a> -->
					<!-- <a class="a2a_button_yoolink"></a> -->
					<!-- <a class="a2a_button_yahoo_mail"></a> -->
					<!-- <a class="a2a_button_yummly"></a> -->
					<!-- <a class="a2a_button_wykop"></a> -->
					<!-- <a class="a2a_button_wanelo"></a> -->
				</div>
			</figure>
		</div>
		</div>
	</div>
	</div>

	<nav class="navbar navbar-expand-xl navbar-light bg-hd br-bottom text-center">
			<a class="navbar-brand text-white" href="index.php"><b style="font-variant: small-caps;">Movie Menu</b></a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="fas fa-cog fa-2x fa-spin text-white"></span>
			</button>

			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav mr-auto">
					<?php $active_page = (isset($_GET['page']) && !empty($_GET['page'])?$_GET['page']:''); ?>
		  			<li class="nav-item <?php echo (empty($active_page) || $active_page == 'index'?'active':''); ?>">
		    			<a class="nav-link" href="<?php echo BASE_URL; ?>" data-id='index'>Home</a>
		  			</li>

		  			<?php 
		  			$data = '';
		  			$result = $connection->selectMovieType($data);
		  			while($ans = mysqli_fetch_assoc($result)): 
		  				if ($ans['main_type_status'] == '1'): ?>
		      			<li class="nav-item <?php echo ($ans['id_movie_type'] == $active_page?'active':''); ?>">
		        			<a class="nav-link" href="<?php echo BASE_URL.'?page='.$ans['id_movie_type']; ?>" data-id='<?php echo $ans['id_movie_type']; ?>'><?php echo $ans['movie_type_title']; ?></a>
		      			</li> <?php
		  				endif;
		  			endwhile; ?>
				</ul>
				<div class="form-inline my-2 my-lg-0 center" action="#">
					<form method="get">
						<input type="hidden" name="page" value="index">
			  			<input class="form-control mr-sm-2" type="text" name="search" placeholder="Search" id='movie-search' aria-label="Search">
			  			<button type="submit" class="btn btn-outline-light my-2 my-sm-0" type="button" id='movie-search-submit'>Search</button>
					</form>
				</div>
			</div>
	</nav>
	
</div>	

<style type="text/css">
	.nav-item a{
		padding: 20px 22px !important;
		color: black !important;
		font-weight: 700;
		text-shadow: 0px 0px 3px black;
		text-transform: uppercase;
		color: white !important;
		transition: all 0.5s;
	}
	.nav-item a:hover{
		background-color: rgba(0,0,0,0.4);
		color: white !important;
		text-shadow: 0px 0px 3px black;
		box-shadow: 0px 0px 4px 2px #AB0025;
	}
	.nav-item a:focus{
		background-color: rgba(0,0,0,0.6);
		color: white !important;
		text-shadow: 0px 0px 3px black;
	}
	.br-bottom{
		border-bottom: 4px solid #AB0025;
	}
	.navbar-brand{
		display: none !important;
	}
	@media (max-width: 1199.98px){
		.navbar-brand{
			display: block !important;
		}
	}
	.custome-advertisement{
		max-width: 100%;
		height: auto;
		overflow: hidden !important;
	}
	.bg-hd{
		background-color: #FF004F;
	}
	nav .line {
	  height: 3px;
	  position: absolute;
	  bottom: 0;
	  margin: 10px 0 0 0;
	  background: #FFFFFF;
	}
	nav ul {
	  padding: 0;
	  margin: 0;
	  list-style: none;
	  display: flex;
	}
	nav ul li:hover {
	  opacity: 0.7;
	}
	nav ul li.active {
	  opacity: 1;
	}

	.dflax {
		width: 100% !important;
		height: auto;
		display: flex;
		justify-content: center;
		flex-wrap: wrap;
		align-items: center;
		flex-direction: row;
	}

</style>

<!-- <script type="text/javascript">
var nav = $('nav');
var line = $('<div />').addClass('line');

line.appendTo(nav);

var active = nav.find('.active');
var pos = 0;
var wid = 0;

if(active.length) {
  pos = active.position().left;
  wid = active.width();
  line.css({
    left: pos,
    width: wid
  });
}

nav.find('ul li a').click(function(e) {
  // e.preventDefault();
  if(!$(this).parent().hasClass('active') && !nav.hasClass('animate')) {
    
    nav.addClass('animate');

    var _this = $(this);

    nav.find('ul li').removeClass('active');

    var position = _this.parent().position();
    var width = _this.parent().width();

    if(position.left >= pos) {
      line.animate({
        width: ((position.left - pos) + width)
      }, 300, function() {
        line.animate({
          width: width,
          left: position.left
        }, 150, function() {
          nav.removeClass('animate');
        });
        _this.parent().addClass('active');
      });
    } else {
      line.animate({
        left: position.left,
        width: ((pos - position.left) + wid)
      }, 300, function() {
        line.animate({
          width: width
        }, 150, function() {
          nav.removeClass('animate');
        });
        _this.parent().addClass('active');
      });
    }

    pos = position.left;
    wid = width;
  }
});
</script> -->