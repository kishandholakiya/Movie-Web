<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Demo-Movie</title>
<link href="../../bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="../../css/style.css" rel="stylesheet" type="text/css"/>
<link href="../../css/media-query.css" rel="stylesheet" type="text/css"/>
<link href="../../css/fontawesome-all.min.css" rel="stylesheet" type="text/css"/>
<link href="../../Owl-CSS/owl.carousel.css" rel="stylesheet" type="text/css"/>
<link href="../../Owl-CSS/owl.carousel.min.css" rel="stylesheet" type="text/css"/>
</head>

<body>


<div class="container-fluid">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-lg-8 title-txt">
				<div class="row no-gutters">
					<div class="col-12">
						<h1>Pad Man Torrent Full Movie Download HD 2018</h1>
						<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
						<hr class="bg-dark"/>
					</div>
					
					<div class="col-12">
						<p>Quick Download Pad Man Torrent Movie 2018 In Your PC, Mobiles & Smart Phones Devices. Pad Man Full Movie Torrent Download With High Quality Here. Pad Man 2018 Is Related To Indian Biography Movies And Indian Drama Movies. We Have Also Wide Collection Of Latest Bollywood Movies In HD Result...</p>
					</div>
					
					<div class="col-12 text-center py-2">
						<h6>Latest Movie Pad Man Download Torrent Link In Bottom</h6>
					</div>
					
					<div class="col-12 py-2 text-center">
						<h2>Pad Man 2018 Hindi Movie Poster</h2>
						<figure>
							<img src="../../images/Post-1.jpg" class="img-fluid" alt="Pad Man Torrent 2018 Hindi Movie Poster" title="Pad Man Torrent 2018 Hindi Movie Poster"/>
						</figure>
					</div>
					
					<div class="col-12 d-flex">
						<div class="box"><strong>Full Movie Name:-</strong></div>
						<div class="box"><strong>Pad Man </strong>2018 Indian Movie</div>	
					</div>
					
					<div class="col-12 d-flex">
						<div class="box"><strong>Movie Genres:-</strong></div>
						<div class="box">Biography, Drama, Comedy</div>	
					</div>
					
					<div class="col-12 d-flex">
						<div class="box"><strong>Movie Release Year:-</strong></div>
						<div class="box">2018</div>	
					</div>
					
					<div class="col-12 d-flex">
						<div class="box"><strong>Movie Language:-</strong></div>
						<div class="box">Hindi</div>	
					</div>
					
					<div class="col-12 d-flex">
						<div class="box"><strong>Movie Size:-</strong></div>
						<div class="box">1.4 GB</div>	
					</div>
					
					<div class="col-12 d-flex">
						<div class="box"><strong>Movie Quality:-</strong></div>
						<div class="box">720p HDRip – x264</div>	
					</div>
					
					<div class="col-12 text-center text-light mt-3">
						<h3 class="bg-main py-2 mb-3">Storyline</h3>
						<p class="px-3">"Biography On Tamil Nadu Activist Arunachalam Muruganantham, Whose Mission Was To Provide Sanitary Napkin’s To Poor Women Of Rural Areas. Who Would Use Rag Cloths Or Leaves During Periods Where Use Of Sanitary Napkins Was Rare. After He Did Not Get Fruitful Results From His Family And A Medical College He Approached, He Decided To Try It Himself By Making A Uterus Out Of Football Bladder And Filling Goat’s Blood In It. He Would Roam Around The Whole Day With The Bladder, The Aim Was To Check The Absorption Rate Of The Sanitary Napkins Made By Him."</p>
					</div>
					
					<div class="col-12 text-light mt-3">
						<h3 class="bg-main py-2 mb-3 text-center">Movie Cast</h3>
						<div class="row no-gutters">
						<div class="col-12 border">
							<div class="row no-gutters borde">
								<div class="col-4 p-2">
									<h6>1.</h6>
								</div>
								<div class="col-4 text-dark align-self-center title-txt">
									<a href="#">Akshay Kumar</a>
								</div>
								<div class="col-4 text-dark align-self-center">
									<p class="m-0">Lakshmikant Chauhan</p>
								</div>
							</div>
						</div>
						<div class="col-12 border">
							<div class="row no-gutters borde">
								<div class="col-4 p-2">
									<h6>2.</h6>
								</div>
								<div class="col-4 text-dark align-self-center title-txt">
									<a href="#">Radhika Apte</a>
								</div>
								<div class="col-4 text-dark align-self-center">
									<p class="m-0">Gayatri</p>
								</div>
							</div>
						</div>
						<div class="col-12 border">
							<div class="row no-gutters borde">
								<div class="col-4 p-2">
									<h6>3.</h6>
								</div>
								<div class="col-4 text-dark align-self-center title-txt">
									<a href="#">Sonam Kapoor</a>
								</div>
								<div class="col-4 text-dark align-self-center">
									<p class="m-0">Rhea</p>
								</div>
							</div>
						</div>
						</div>
					</div>
					
					<div class="col-12 my-4">
						<h3 class="bg-main text-center text-light py-2">Pad Man 2018 Hindi Movie Poster</h3>
						<figure>
							<img src="../../images/Post-1.jpg" class="img-fluid" alt="Pad Man Torrent 2018 Hindi Movie Poster" title="Pad Man Torrent 2018 Hindi Movie Poster"/>
						</figure>
					</div>
					
					<div class="col-12">
						<h3 class="bg-main p-2 mb-0 text-center text-light">Pad Man Full Movie Details</h3>
						<p class="py-2 text-center">Pad Man Is An 2018 Indian Biographical Comedy Drama Film Written And Directed By R. Balki, Featuring Akshay Kumar, Sonam Kapoor And Radhika Apte In Lead Roles. It Is Based On A Short Story In Twinkle Khanna’s Book The Legend Of Lakshmi Prasad And Is Inspired By The Life Of Arunachalam Muruganantham, A Social Activist From Tamil Nadu.</p>
					</div>
					
					<div class="col-12">
						<h3 class="bg-main p-2 mb-0 text-center text-light">Pad Man 2018 Movie Result Sample Pictures</h3>
						<div class="owl-carousel owl-theme my-3">
    						<div class="item">
    							<figure>
    								<a href="#">
    									<img src="../../images/Post-1.jpg" class="img-fluid" alt="1" title="1"/>
    								</a>
    							</figure>
    						</div>
    						<div class="item">
    							<figure>
    								<a href="#">
    									<img src="../../images/Post-1.jpg" class="img-fluid" alt="2" title="2"/>
    								</a>
    							</figure>
    						</div>
    						<div class="item">
    							<figure>
    								<a href="#">
    									<img src="../../images/Post-1.jpg" class="img-fluid" alt="3" title="3"/>
    								</a>
    							</figure>
    						</div>
    						<div class="item">
    							<figure>
    								<a href="#">
    									<img src="../../images/Post-1.jpg" class="img-fluid" alt="4" title="4"/>
    								</a>
    							</figure>
    						</div>
    						<div class="item">
    							<figure>
    								<a href="#">
    									<img src="../../images/Post-1.jpg" class="img-fluid" alt="5" title="5"/>
    								</a>
    							</figure>
    						</div>
						</div>
					</div>
					
					<div class="col-12 text-center">
						<h3 class="bg-main p-2 text-light">Pad Man Movie Download Full</h3>
						<h6 class="py-2 down"><b>Movie Download Link Update 13 May 2018</b></h6>
						<a href="#id" class="flipper-container" onclick="window.open('http://www.google.com')">
  							<div id="id" class="flipper">
    							<div class="front-face" data-icon="&#x27a3;"><span data-hover="Clicked">Click Me</span></div>
    							<div class="back-face" data-icon="&#10003;">Thank You</div>
  							</div>
						</a>
						<a href="#id1" class="flipper-container" onclick="window.open('http://www.google.com')">
  							<div id="id1" class="flipper">
    							<div class="front-face" data-icon="&#x27a3;"><span data-hover="Clicked">Click Me</span></div>
    							<div class="back-face" data-icon="&#10003;">Thank You</div>
  							</div>
						</a>
						<a href="#id2" class="flipper-container" onclick="window.open('http://www.google.com')">
  							<div id="id2" class="flipper">
    							<div class="front-face" data-icon="&#x27a3;"><span data-hover="Clicked">Click Me</span></div>
    							<div class="back-face" data-icon="&#10003;">Thank You</div>
  							</div>
						</a>
					</div>
					
					<div class="col-12 text-center">
					<h6 class="pt-3 pb-5 down"><b>Pad Man Movie Magnet Torrent Download 1.4 GB</b></h6>
					 <a href="#">
						 <div class="button text-light mt-5 mb-5">
      						<div class="don">
       						<em>Download</em>
        					<i class="fa fa-download"></i>
        					</div>
    					</div>
    				</a>
					</div>
				</div>
			</div>
			<div class="col-sm-12 col-lg-4 left-title">
							<div class="box-100">
								<h3><b>UPCOMING MOVIE RACE 3 COMING SOON</b></h3>
								<figure>
									<img src="../../images/Post-1.jpg" class="img-fluid" alt="UPCOMING MOVIE" title="UPCOMING MOVIE"/>
									<figcaption><a href="#">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</a></figcaption>
								</figure>
							</div>
							<div class="box-100">
							<div class="tag text-light">Up Coming Movies</div>
								<div class="row my-2">
									<div class="col-md-5 col-lg-5 pr-0">
										<figure>
											<img src="../../images/Post-1.jpg" class="img-fluid h" alt="Lucknow Central Torrent Full Movie" title="Lucknow Central Torrent Full Movie "/>
										</figure>
									</div>
									<div class="col-md-5 col-lg-7 title-txt my-auto">
										<h5><a href="#">Missing Torrent Full Movie Download HD 2018 Missing Torrent Full Movie Download HD 2018</a></h5>
									</div>
									<div class="col-12 title-txt coming">
										<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
										<hr/>
									</div>
								</div>
								<div class="row my-2">
									<div class="col-md-5 col-lg-5 pr-0">
										<figure>
											<img src="../../images/Post-1.jpg" class="img-fluid h" alt="Lucknow Central Torrent Full Movie" title="Lucknow Central Torrent Full Movie "/>
										</figure>
									</div>
									<div class="col-md-5 col-lg-7 title-txt my-auto">
										<h5><a href="#">Missing Torrent Full Movie Download HD 2018 Missing Torrent Full Movie Download HD 2018</a></h5>
									</div>
									<div class="col-12 title-txt coming">
										<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
										<hr/>
									</div>
								</div>
								<div class="row my-2">
									<div class="col-md-5 col-lg-5 pr-0">
										<figure>
											<img src="../../images/Post-1.jpg" class="img-fluid h" alt="Lucknow Central Torrent Full Movie" title="Lucknow Central Torrent Full Movie "/>
										</figure>
									</div>
									<div class="col-md-5 col-lg-7 title-txt my-auto">
										<h5><a href="#">Missing Torrent Full Movie Download HD 2018 Missing Torrent Full Movie Download HD 2018</a></h5>
									</div>
									<div class="col-12 title-txt coming">
										<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
										<hr/>
									</div>
								</div>
								<div class="row my-2">
									<div class="col-md-5 col-lg-5 pr-0">
										<figure>
											<img src="../../images/Post-1.jpg" class="img-fluid h" alt="Lucknow Central Torrent Full Movie" title="Lucknow Central Torrent Full Movie "/>
										</figure>
									</div>
									<div class="col-md-5 col-lg-7 title-txt my-auto">
										<h5><a href="#">Missing Torrent Full Movie Download HD 2018 Missing Torrent Full Movie Download HD 2018</a></h5>
									</div>
									<div class="col-12 title-txt coming">
										<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
										<hr/>
									</div>
								</div>
								<div class="row my-2">
									<div class="col-md-5 col-lg-5 pr-0">
										<figure>
											<img src="../../images/Post-1.jpg" class="img-fluid h" alt="Lucknow Central Torrent Full Movie" title="Lucknow Central Torrent Full Movie "/>
										</figure>
									</div>
									<div class="col-md-5 col-lg-7 title-txt my-auto">
										<h5><a href="#">Missing Torrent Full Movie Download HD 2018 Missing Torrent Full Movie Download HD 2018</a></h5>
									</div>
									<div class="col-12 title-txt coming">
										<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
										<hr/>
									</div>
								</div>
								<div class="row my-2">
									<div class="col-md-5 col-lg-5 pr-0">
										<figure>
											<img src="../../images/Post-1.jpg" class="img-fluid h" alt="Lucknow Central Torrent Full Movie" title="Lucknow Central Torrent Full Movie "/>
										</figure>
									</div>
									<div class="col-md-5 col-lg-7 title-txt my-auto">
										<h5><a href="#">Missing Torrent Full Movie Download HD 2018 Missing Torrent Full Movie Download HD 2018</a></h5>
									</div>
									<div class="col-12 title-txt coming">
										<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
										<hr/>
									</div>
								</div>
								<div class="row my-2">
									<div class="col-md-5 col-lg-5 pr-0">
										<figure>
											<img src="../../images/Post-1.jpg" class="img-fluid h" alt="Lucknow Central Torrent Full Movie" title="Lucknow Central Torrent Full Movie "/>
										</figure>
									</div>
									<div class="col-md-5 col-lg-7 title-txt my-auto">
										<h5><a href="#">Missing Torrent Full Movie Download HD 2018 Missing Torrent Full Movie Download HD 2018</a></h5>
									</div>
									<div class="col-12 title-txt coming">
										<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
										<hr/>
									</div>
								</div>
								<div class="row my-2">
									<div class="col-md-5 col-lg-5 pr-0">
										<figure>
											<img src="../../images/Post-1.jpg" class="img-fluid h" alt="Lucknow Central Torrent Full Movie" title="Lucknow Central Torrent Full Movie "/>
										</figure>
									</div>
									<div class="col-md-5 col-lg-7 title-txt my-auto">
										<h5><a href="#">Missing Torrent Full Movie Download HD 2018 Missing Torrent Full Movie Download HD 2018</a></h5>
									</div>
									<div class="col-12 title-txt coming">
										<time><i class="far fa-clock mt-2 ml-3"></i><span class="pl-4">May 25,2018</span></time>
										<hr/>
									</div>
								</div>

							</div>	
						</div>
		</div>
	</div>
</div>



<div class="container-fluid bg-main1 py-4 text-light">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<h6><strong>Most searched for on Billionairehub</strong></h6>
				<hr class="bg-light"/>
			</div>
			<div class="col-12 footer-text">
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
				<a href="#">MSI Laptop</a>|
			</div>
		</div>
	</div>
</div>

<div class="container-fluid bg-fotter">
		<div class="container">
		<footer class="row justify-content-between">
				<div class="col-lg-6">
					<ul class="footer-policy mb-0">
						<li><a href="Privacy-Policy.php">Privacy &amp; Policy</a></li>
						<li><a href="Terms of Use.php">Terms of Use</a></li>
						<li><a href="Contact Form.php">Contact US</a></li>
					</ul>
				</div>
				<div class="col-lg-4">
					<p class="copyright-text mb-0 text-light">© 2018 Billionairehub.com</p>
				</div>
			</footer>
		</div>
	</div>



<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" crossorigin="anonymous"></script>
<script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
<script src="Owl-JS/jquery.min.js"></script>
<script src="Owl-JS/owl.carousel.min.js"></script>
<script>
	$('.owl-carousel').owlCarousel({
    loop:true,
	dots:false,
	autoplay:true,
	autoplayTimeout:2000,
    margin:10,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
        },
        600:{
            items:1,
        },
        1000:{
            items:2,
        }
    }
});
</script>
</body>
</html>
