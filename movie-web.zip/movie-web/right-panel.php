<div class="col-sm-12 col-lg-4 left-title">
	<div class="add-area-side">
		
	</div>
	<div class="box-100">
		<?php 
		// $data = array();
		// $data['start'] = 0;
		// $data['limit'] = 1;
		// $return = $connection->selectUpcommingMovie($data);
		// $html = '';
		// while($ans = mysqli_fetch_assoc($return)) {
		// 	if ($ans['movie_is_status'] == '1') {
		// 		$timestamp = strtotime($ans['movie_release_date']); 
		// 		$new_date = date('M d,Y', $timestamp);
		// 		$html .= '<h3><b>'.$ans['movie_sub_title'].'</b></h3>
		// 		<figure>
		// 			<img src="images/movie-img/'.$ans['movie_info_img'].'" class="img-fluid" alt="'.$ans['movie_name'].'" title="'.$ans['movie_name'].'"/>
		// 			<figcaption><a href="#" class="wb-movie-info-name" data-movie-id="'.$ans['id_movie_info'].'">'.$ans['movie_name'].'</a></figcaption>
		// 		</figure>';
		// 	}
		// }
		// echo $html; ?>

		<h3><b>New Up Coming Movies</b></h3>
			<figure>
				<div class='main-slider-info-2 owl-carousel owl-theme'>
				<?php 
				$data = '';
				$result = $connection->selectSliderInformation2($data); 
				while($ans = mysqli_fetch_assoc($result)) { 
					if ($ans['slider_is_status'] == '1') { ?>
						<div class='item'>
							<figure>
								<a href='<?php echo $ans['slider_link']; ?>'>
									<img src="images/slider-img2/<?php echo $ans['slider_img']; ?>" class='img-fluid' alt='1' title="<?php echo $ans['slider_name']; ?>"/>
								</a>
							</figure>
						</div> <?php 
					} 
				} ?>
			<!-- <img src="images/Main-Poster/robot2-0-min.jpg" class="img-fluid" alt="img-name" title="img-mname"> -->
				</div>
		</figure>
	</div>

	<div class="box-100">
	<div class="tag text-light">New Up-Coming Movies List</div>
		<?php 
		$data = array();
		$data['start'] = 0;
		$data['limit'] = 8;
		$data['id_movie_type'] = 5;
		$data['search'] = '';
		$data['movie'] = '';
		$return = $connection->selectMovieList($data);
		$html = '';
		$i = 1;
		$total_record = 10;
		while($ans = mysqli_fetch_assoc($return)) {
			if ($i <= $total_record) {
				if ($ans['movie_is_status'] == '1') {
					$timestamp = strtotime($ans['movie_release_date']); 
					$new_date = date('M d,Y', $timestamp);
					$html .= '<div class="row my-2">
						<div class="col-md-5 col-lg-5 pad-set">
							<figure>
								<img src="images/movie-img/'.$ans['movie_info_img'].'" class="img-fluid h" alt="'.$ans['movie_name'].'" title="'.$ans['movie_name'].'"/>
							</figure>
						</div>
						<div class="col-md-5 col-lg-7 title-txt my-auto">
							<h5><a href="#" class="wb-movie-info-name" data-movie-id="'.$ans['id_movie_info'].'">'.$ans['movie_name'].'</a></h5>
						</div>
						<div class="col-12 title-txt coming">
							<time><i class="far fa-clock mt-2"></i><span class="pl-2">'.$new_date.'</span></time>
							<hr/>
						</div>
					</div>'; 
				}
			}
			$i++;
		}
		echo $html; ?>
	</div>	
	<div class="add-area-side">
		
	</div>
</div> 
