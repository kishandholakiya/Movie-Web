<style type="text/css">
	.text-sub{
		font-weight: 700;
		font-size: 40px;
		text-shadow: 0px 0px 4px black;
	}
	.text-sub-1{
		font-weight: 500;
		font-size: 18px;
		color: white;
		text-shadow: 0px 0px 4px gray;
	}
	.input-set-sub{
		width: 50%;
		height: 55px;
		text-indent: 25px;
		font-weight: 600;
		border: 1px solid white;
		border-radius: 5px;
		transition: all 0.5s ease-in-out;
	}
	.input-set-sub:focus{
		background-color: #fff;
	}
	.subscribe-input{
		width: 120px;
		height: 55px;
		font-weight: 600;
		font-size: 20px;
		cursor: pointer;
		background-color: #a00025;
		border: 1px solid white;
		transition: all 0.5s ease-in-out;
		color: white;
		border-radius: 5px;
	}
	.subscribe-input:hover
	{
		background-color: white;
		color: #a00025;
	}
	@media (max-width: 575.98px) {
		.input-set-sub{
			width: 100%;
		}
		.subscribe-input{
			margin-top: 15px !important;
		}
	}
	.set-color{
		background-color: #FF004F !important;
	}
	.put-add-hear{
		width: 100%;
		height: auto;
	}
</style>

<div class="container-fluid">
	<div class="container">
		<div class="row">
			<div class="put-add-hear">
				
			</div>			
		</div>
	</div>
</div>

<div class="container-fluid set-color text-light p-3">
	<div class="row justify-content-center">
		<div class="col-lg-6 text-center">
			<article>
				<span class="text-sub">Subscribe Now</span>
				<p class="text-sub-1">When we Upload New Movie at that Time you get Notification via Email - &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; it's Free .........</p>
			</article>
			<!-- <form method="get" action="#">  -->
				<input type="email" required name="email-sub" class="input-set-sub" placeholder="Enter Email Address">
				<input type="button" value="Subscribe" class="subscribe-input">
			<!-- </form> -->
		</div>
		<div class="col-12">
			
		</div>
	</div>
</div>



<div class="container-fluid bg-main1 py-4 text-light">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<h6><strong class="text-white">Most searched for on freemovie4you</strong></h6>
				<hr class="bg-light"/>
			</div>
			<div class="col-12 footer-text">
				<a href="index.php">freemovie4you</a>|
				<a href="index.php">freemovieforyou</a>|
				<a href="index.php">freemoviesforyou</a>|
				<a href="index.php">free movies download</a>|
				<a href="index.php">free movie 4 you</a>
				<a href="index.php">freemovies4you</a>|
				<a href="index.php">free movies 4 you</a>|
				<a href="index.php">free movie download</a>|
				<a href="index.php">free movie downloder</a>|
				<a href="index.php">hindi movie download</a>|
				<a href="index.php">hd movies download</a>|
				<a href="index.php">new movie download</a>|
				<a href="index.php">bollywood movies download</a>|
				<a href="index.php">torrents movies download</a>|
				<a href="index.php">full hd movies download</a>|
				<a href="index.php">hd movies website</a>|
				<a href="index.php">hd movies download website</a>|
				<a href="index.php">new gujarati movies download</a>|
				<a href="index.php">gujarati movies download</a>|
				<a href="index.php">full hd movies download 1080p free download</a>
			</div>
		</div>
	</div>
</div>

<div class="container-fluid bg-fotter">
	<div class="container">
		<footer class="row justify-content-between">
			<div class="col-lg-6">
				<ul class="footer-policy mb-0">
					<li><a href="Privacy-Policy.php">Privacy &amp; Policy</a></li>
					<li><a href="Terms-of-Use.php">Terms of Use</a></li>
					<li><a href="Contact-Form.php">Contact US</a></li>
				</ul>
			</div>
			<div class="col-lg-4">
				<p class="copyright-text mb-0 text-light">© <?php echo date("Y"); ?> freemovie4you.com</p>
			</div>
		</footer>
	</div>
</div>
